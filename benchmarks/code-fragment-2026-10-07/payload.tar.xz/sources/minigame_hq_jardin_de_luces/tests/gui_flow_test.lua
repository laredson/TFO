-- Exercises the production GUI callbacks with a minimal deterministic GUI adapter.
-- This checks state transitions and hit regions, not rendering or real OS input.
package.path = "./?.lua;" .. package.path
hash = function(v) return v end
vmath = {vector3=function(x,y,z) return {x=x,y=y,z=z} end,vector4=function(x,y,z,w) return {x=x,y=y,z=z,w=w} end}
msg = {post=function() end}
gui = {}
local function node(p,s) return {p=p,s=s or {x=0,y=0},alive=true} end
gui.new_box_node=node; gui.new_pie_node=node
gui.new_text_node=function(p,t) local n=node(p); n.text=t; return n end
for _,name in ipairs({"set_color","set_font","set_scale","set_rotation","set_perimeter_vertices"}) do gui[name]=function(n) assert(n.alive) end end
gui.delete_node=function(n) assert(n.alive); n.alive=false end
gui.pick_node=function(n,x,y) assert(n.alive); return math.abs(x-n.p.x)<=n.s.x/2 and math.abs(y-n.p.y)<=n.s.y/2 end
assert(loadfile("main/game.gui_script"))()
local s={}
init(s)
local checks=0
local function check(v,message) checks=checks+1; assert(v,message) end
local function click(id)
 local target
 for _,b in ipairs(s.buttons) do if b.id==id then target=b.node end end
 assert(target,"missing control "..id)
 on_input(s,"touch",{pressed=true,x=target.p.x,y=target.p.y})
end
local function stock()
 local n=0; for _,v in pairs(s.state.remaining) do n=n+v end; return n
end
check(stock()==16,"initial inventory")
click("word:bool"); check(stock()==16 and #s.state.sequence==0,"locked tile spent")
click("help:loop"); check(s.help=="loop","help")
update(s,1.2); click("close"); check(not s.help,"close")
click("word:false"); click("plant")
check(s.state.level==1 and s.error,"wrong plant")
click("undo"); check(stock()==16 and #s.state.sequence==0,"undo recovery")
local paths={{"true","true","true"},{"true","bool","loop"},{"false","false","true","true","loop"},{"true","true","false","fragment"},{"true","false","false","true","loop"}}
for i,path in ipairs(paths) do
 for _,word in ipairs(path) do click("word:"..word) end
 check(require("main.rules").matches(s.state),"target "..i)
 click("plant"); check(s.state.planted==i,"plant "..i)
 check(s.celebrate>1,"celebration")
 update(s,2)
 click("continue"); check(s.celebrate==0,"continue")
end
check(s.state.won,"win")
click("plant"); check(not s.state.won and s.state.level==1 and stock()==16,"again")
click("word:true"); click("clear"); check(stock()==16 and #s.state.sequence==0,"clear")
click("word:false"); click("reset"); check(stock()==16 and s.state.planted==0 and #s.state.sequence==0,"reset")
print("PASS GUI callback flow: "..checks.." checks; five orders, error, undo, help, clear, victory, both reset controls")
print("LIMIT: deterministic GUI adapter; no visual rendering or operating-system input validation")
