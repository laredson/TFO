package.path = './?.lua;' .. package.path
local rules = require('main.rules')
local checks = 0
local function check(value, message)
    checks = checks+1
    assert(value, message or ('check '..checks))
end
local function equal(a,b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= 'table' then return a == b end
    for k,v in pairs(a) do if not equal(v,b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
local function clone(t)
    if type(t) ~= 'table' then return t end
    local c = {}; for k,v in pairs(t) do c[k] = clone(v) end; return c
end
local function total(t)
    local n=0; for _,v in pairs(t) do n=n+v end; return n
end
local function sequence(s)
    return table.concat(s.sequence)
end
local function apply_all(state, words)
    for word in words:gmatch('%S+') do
        local ok,msg=rules.apply(state,word); check(ok, word..': '..msg)
    end
end
local initial = {loop=3,bool=2,['not']=2,['true']=3,['false']=3,['end']=2,fragment=1}
local start=rules.new()
check(equal(start,{level=1,sequence={},history={},remaining=initial,won=false,planted=0}), 'new contract')
check(total(start.remaining)==16)
local another=rules.new(); start.remaining.loop=0
check(another.remaining.loop==3, 'independent instances')
local unlock={loop=1,bool=2,['not']=3,['true']=1,['false']=1,['end']=1,fragment=4}
for level=1,5 do
    local s=rules.new(); s.level=level
    for _,word in ipairs(rules.words) do check(rules.is_unlocked(s,word)==(level>=unlock[word]), 'unlock '..word) end
end
check(not rules.is_unlocked(another,'unknown'))

-- Independently compute outputs as strings, covering all binary rows of length 0..8.
local function expected(row,word)
    if word=='true' then return row..'1' end
    if word=='false' then return row..'0' end
    if #row==0 then return nil end
    if word=='loop' then return row..row end
    if word=='fragment' then return row..row:reverse() end
    if word=='end' then return row:sub(1,-2) end
    if word=='not' then return (row:gsub('[01]', {['0']='1',['1']='0'})) end
    if word=='bool' then return (row:gsub('[01]', {['0']='01',['1']='10'})) end
end
local transform_cases=0
for length=0,8 do
    for bits=0,2^length-1 do
        local row=''
        for i=length-1,0,-1 do row=row..tostring(math.floor(bits/2^i)%2) end
        for _,word in ipairs(rules.words) do
            local s=rules.new(); s.level=5
            for digit in row:gmatch('.') do s.sequence[#s.sequence+1]=tonumber(digit) end
            local before=clone(s)
            local output=expected(row,word)
            local valid=output~=nil and #output<=8
            local ok,message=rules.apply(s,word)
            check(ok==valid, 'validity '..row..' '..word)
            check(type(message)=='string' and #message>0)
            if valid then
                check(sequence(s)==output, 'transform '..row..' '..word)
                check(total(s.remaining)==15 and s.remaining[word]==initial[word]-1)
                check(#s.history==1 and s.history[1]==word)
                check(s.level==5 and s.planted==0 and not s.won)
            else
                check(equal(s,before), 'invalid must be atomic')
            end
            transform_cases=transform_cases+1
        end
    end
end
-- Every locked, unknown and exhausted operation leaves the entire state unchanged.
for level=1,5 do
    for _,word in ipairs(rules.words) do
        local s=rules.new(); s.level=level; s.sequence={1,0}
        if not rules.is_unlocked(s,word) then
            local before=clone(s); check(not rules.apply(s,word)); check(equal(s,before))
        end
        s.remaining[word]=0
        local before=clone(s); check(not rules.apply(s,word)); check(equal(s,before))
    end
end
for _,word in ipairs({'unknown','', 'TRUE'}) do
    local s=rules.new(); local before=clone(s)
    check(not rules.apply(s,word)); check(equal(s,before))
end
local s=rules.new(); apply_all(s,'true true true')
local before=clone(s); check(not rules.apply(s,'true')); check(equal(s,before))
-- Undo reconstructs all previous states and returns every used counter correctly.
s=rules.new(); s.level=5
local snapshots={clone(s)}
for word in ('true false bool not end end loop fragment'):gmatch('%S+') do
    check(rules.apply(s,word)); snapshots[#snapshots+1]=clone(s)
end
for i=#snapshots-1,1,-1 do check(rules.undo(s)); check(equal(s,snapshots[i]),'undo replay') end
before=clone(s); check(not rules.undo(s)); check(equal(s,before))
apply_all(s,'false true loop'); rules.clear(s)
check(equal(s,snapshots[1]), 'clear restores recipe, keeps progression')
-- A mismatched or empty row cannot advance the tree.
s=rules.new(); before=clone(s)
check(not rules.matches(s)); check(not rules.plant(s)); check(equal(s,before))
apply_all(s,'true false true'); before=clone(s)
check(not rules.matches(s)); check(not rules.plant(s)); check(equal(s,before))
rules.clear(s)
local solutions={
    'true true true',
    'true bool loop',
    'false false true true loop',
    'true true false fragment',
    'true false false true loop',
}
for level,recipe in ipairs(solutions) do
    apply_all(s,recipe)
    check(rules.matches(s), 'solution '..level)
    print('PASS level '..level..': '..recipe..' -> '..sequence(s))
    check(rules.plant(s)); check(s.planted==level and s.level==level+1)
    check(#s.sequence==0 and #s.history==0 and equal(s.remaining,initial))
    check(s.won==(level==5))
end
before=clone(s)
check(not rules.matches(s)); check(not rules.plant(s)); check(not rules.apply(s,'true'))
check(not rules.undo(s)); check(equal(s,before), 'victory stays stable')
local same=s; rules.reset(s)
check(s==same and equal(s,rules.new()), 'reset mutates same object')
check(total(s.remaining)==16)
-- New unlocked words are optional, including at level 2.
s.level=2; apply_all(s,'true false loop'); check(rules.matches(s)); check(rules.plant(s))
print('PASS '..checks..' checks; '..transform_cases..' exhaustive transformations; five wins and reset')
