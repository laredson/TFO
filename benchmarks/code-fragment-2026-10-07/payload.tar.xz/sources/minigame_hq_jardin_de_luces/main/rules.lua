-- Pure Lua game rules; no Defold dependencies.
local M = {}
M.words = {"loop", "bool", "not", "true", "false", "end", "fragment"}
M.levels = {
    {target={1,1,1}, title="Tres soles", hint="Pon tres soles."},
    {target={1,0,1,0}, title="Sol y luna", hint="Un sol, su opuesta... y repite."},
    {target={0,0,1,1,0,0,1,1}, title="Lunas y soles", hint="Dos lunas, dos soles... y repite."},
    {target={1,1,0,0,1,1}, title="Un espejo", hint="Dos soles y una luna. ¡Refleja!"},
    {target={1,0,0,1,1,0,0,1}, title="El jardín brilla", hint="Sol, luna, luna, sol... y repite."},
}
local initial = {loop=3, bool=2, ["not"]=2, ["true"]=3, ["false"]=3, ["end"]=2, fragment=1}
local unlock = {loop=1, bool=2, ["not"]=3, ["true"]=1, ["false"]=1, ["end"]=1, fragment=4}
local function copy(source)
    local result = {}
    for k,v in pairs(source) do result[k] = v end
    return result
end
local function clean_recipe(state)
    state.sequence, state.history, state.remaining = {}, {}, copy(initial)
end
function M.new()
    local state = {level=1, won=false, planted=0}
    clean_recipe(state)
    return state
end
function M.is_unlocked(state, word)
    return unlock[word] ~= nil and state.level >= unlock[word]
end
function M.apply(state, word)
    if state.won then return false, "¡Tu jardín ya brilla!" end
    if not unlock[word] then return false, "Elige una ficha." end
    if not M.is_unlocked(state, word) then return false, "Esta ficha se abrirá pronto." end
    if state.remaining[word] <= 0 then return false, "Ya usaste estas fichas." end
    local result = copy(state.sequence)
    local count = #result
    if word == "true" or word == "false" then
        result[count+1] = word == "true" and 1 or 0
    elseif word == "end" then
        if count == 0 then return false, "Primero pon una luz." end
        result[count] = nil
    elseif word == "not" then
        if count == 0 then return false, "Primero pon una luz." end
        for i=1,count do result[i] = 1-result[i] end
    elseif word == "bool" then
        if count == 0 then return false, "Primero pon una luz." end
        result = {}
        for i=1,count do
            result[#result+1] = state.sequence[i]
            result[#result+1] = 1-state.sequence[i]
        end
    elseif word == "loop" or word == "fragment" then
        if count == 0 then return false, "Primero pon una luz." end
        for i=1,count do
            result[count+i] = state.sequence[word == "loop" and i or count-i+1]
        end
    end
    if #result > 8 then return false, "Solo caben ocho luces." end
    state.sequence = result
    state.remaining[word] = state.remaining[word]-1
    state.history[#state.history+1] = word
    return true, "¡Mira cómo cambia!"
end
function M.undo(state)
    if state.won or #state.history == 0 then return false, "No hay pasos que deshacer." end
    local history = copy(state.history)
    history[#history] = nil
    clean_recipe(state)
    for _,word in ipairs(history) do assert(M.apply(state, word)) end
    return true, "Un paso atrás."
end
function M.clear(state)
    clean_recipe(state)
    return true, "¡Probemos otra vez!"
end
function M.matches(state)
    if state.won then return false end
    local level = M.levels[state.level]
    if not level or #state.sequence ~= #level.target then return false end
    for i,value in ipairs(level.target) do
        if state.sequence[i] ~= value then return false end
    end
    return true
end
function M.plant(state)
    if state.won then return false, "¡Tu jardín ya brilla!" end
    if not M.matches(state) then return false, "Mira el pedido. ¡Tú puedes!" end
    state.planted = state.planted+1
    state.level = state.level+1
    clean_recipe(state)
    state.won = state.planted == #M.levels
    return true, state.won and "¡Tu jardín brilla!" or "¡Una rama llena de luz!"
end
function M.reset(state)
    for key in pairs(state) do state[key] = nil end
    for key,value in pairs(M.new()) do state[key] = value end
    return state
end
return M
