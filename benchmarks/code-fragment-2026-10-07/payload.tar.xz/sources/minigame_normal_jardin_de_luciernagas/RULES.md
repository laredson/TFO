# Jardín de luciérnagas — contrato lógico

`garden.lua` es un módulo Lua puro compatible con Lua 5.1+, sin APIs Defold.
Integración: `local garden = require("garden")` (o la ruta de módulo elegida al integrar).

## Estado y API

- `new()` devuelve `{stage=1, won=false, inventory={...}}`, con inventario independiente: `loop=3`, `bool=2`, `not=2`, `true=3`, `false=3`, `end=2`, `fragment=1`. Todas las claves de fichas son strings; usar `inventory["true"]` y fichas `"true"`, nunca booleanos Lua.
- `unlocked(state, word)` devuelve booleano. Etapa 1: true/false; etapa 2 añade loop/bool/not; etapa 3 añade fragment/end. Una ficha desconocida devuelve false.
- `available(state, word, program)` devuelve booleano: ficha desbloqueada, cantidad restante y menos de ocho posiciones ocupadas. `program` puede omitirse. La UI debe mantenerlo como lista continua válida.
- `targets(state)` devuelve una copia de la lista de colores del reto actual: `{"green","green"}`, `{"green","blue","green","blue"}`, `{"green","blue","blue","green","green","blue","blue","green"}`.
- `simulate(state, program)` devuelve `{pulses={}, trace={}, matched=number, mismatches={}, error=string opcional}`. No modifica estado, inventario ni programa.
- `submit(state, program)` devuelve lo mismo más `success=boolean`. Si no hay error y todos los objetivos coinciden, avanza una etapa o activa `won=true` en etapa 3. El resultado corresponde al reto anterior al avance; guardar ese resultado si la UI anima el envío. Consultar `targets(state)` después del envío para el próximo reto. Tras ganar, nuevos envíos devuelven success=false y conservan el estado.

`program` es una lista continua de strings, como `{"bool","true","loop"}`. Máximo ocho fichas. Se validan desbloqueos y cantidades de todo el programa, incluso después de end. Los errores de validación no emiten pulsos y producen una traza vacía. El inventario se reutiliza por completo en cada simulación/envío: no se consume de forma permanente. Se asume un estado creado mediante new(); la UI puede leerlo pero no debe alterar sus campos fuera de esta API.

## Semántica

No hay sintaxis de bloques: cualquier orden de fichas desbloqueadas es válido, excepto loop sin un emisor anterior.

- true emite green; false emite blue.
- not conmuta inversión de los colores posteriores. Otro not restaura la inversión anterior.
- bool activa alternancia y empieza con fase sin inversión adicional. Cada pulso posterior cambia la fase. Repetir bool mantiene la alternancia y su fase; no la reinicia. La inversión de not y la fase de bool se combinan, por lo que dos inversiones se cancelan.
- loop añade **tres repeticiones adicionales** del último emisor (true/false/fragment), aplicando los modificadores actuales a cada repetición. No repite controles ni el color ya calculado. Varios loop siguen usando el mismo emisor.
- fragment emite `"rainbow"`, comodín que coincide con cualquier color objetivo. not no modifica rainbow; un pulso rainbow sí cambia la fase de bool. loop puede repetir fragment.
- end detiene la ejecución; no emite. Los tokens posteriores no se ejecutan.

Se comparan únicamente las primeras N luces, donde N es la longitud del objetivo. Los pulsos extra se conservan en el resultado pero no afectan el éxito. `matched` cuenta todas las posiciones coincidentes (no solo un prefijo continuo). Cada elemento de `mismatches` incluye `{index, expected, actual, reason}`: reason es `"color"` o `"missing"`; actual falta/nil cuando no se emitió esa posición. La UI puede mostrar el número de coincidencias y resaltar cada índice incorrecto.

Cada entrada de trace es `{index, word, pulses={...}}`, una por ficha ejecutada. Los controles tienen pulses vacío; loop incluye sus tres luces. end añade `stopped=true`; un loop sin emisor añade `error` a su paso y al resultado, con mensaje amistoso. Toda simulación reinicia los modificadores.

## Soluciones verificables

1. `{"true","true"}` → GG.
2. `{"bool","true","loop"}` → GBGB.
3. `{"true","false","false","true","true","false","bool","loop"}` → GBBGGBBGB. Las primeras ocho luces son GBBGGBBG; la novena se ignora. Cumple exactamente tres true, tres false, un bool y un loop.

Alternativa de etapa 3: `{"fragment","loop","loop","true"}` produce siete comodines y una luz verde.

## Pruebas

Con un intérprete Lua: ejecutar desde esta carpeta `lua tests/test_garden.lua`.
El runner opcional `python tests/run_tests.py` usa Lupa instalado localmente en `.test-runtime` y ejecuta la misma suite en Lua 5.1, Lua 5.4 y LuaJIT 2.1.
No se compiló ni ejecutó Defold. La integración de escenas/UI corresponde al principal.
