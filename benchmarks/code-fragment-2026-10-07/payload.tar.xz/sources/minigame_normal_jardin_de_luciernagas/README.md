# Jardín de luciérnagas

Minijuego independiente para la consola de Code Fragment. Despierta tres capullos creando mezclas de luces. Una sola pantalla, ratón, sin escribir código. Está pensado para explorar durante unos 2–3 minutos; esa duración y la comprensión infantil todavía no se han medido con jugadores.

## Abrir

En Windows abre `dist/Code Fragment Console/CodeFragmentConsole.exe`. Mantén junto al ejecutable los cuatro archivos `game.*`. También puedes abrir `game.project` con Defold 1.13.1 instalado y ejecutar el proyecto. No requiere assets descargados ni extensiones.

## Jugar

1. Mira las luces de QUIERE: `+` verde y `o` azul.
2. Toca fichas para colocarlas en TU MEZCLA (máximo ocho). SALDRA muestra su efecto antes de enviar.
3. Pulsa VOLAR. Las luces se muestran en orden y los aciertos llevan OK; un color distinto lleva X.
4. Si no coincide, toca una ficha de TU MEZCLA para devolverla o usa Vaciar. Prueba de nuevo; no pierdes fichas ni capullos abiertos.
5. Abre los tres capullos para ganar. Otra vez o Reiniciar comienza una nueva partida. El botón amarillo ofrece ayuda.

Inventario original visible, 16 fichas: loop ×3, bool ×2, not ×2, true ×3, false ×3, end ×2 y fragment ×1. Las fichas colocadas se reservan para esa mezcla; al quitarlas o completar un capullo vuelven. Las grises se desbloquean al avanzar, o están colocadas en la mezcla.

## Reglas

| Ficha | Efecto |
|---|---|
| true | Una luz verde `+`. |
| false | Una luz azul `o`. |
| loop | Tres luces adicionales del último emisor true, false o fragment. Los modificadores se aplican a cada copia. Sin emisor previo, invita a colocar una luz primero. |
| bool | Activa alternancia: la primera luz conserva su color y cada pulso posterior invierte la fase. Otro bool no reinicia la fase. |
| not | Invierte todos los colores siguientes; otro not cancela la inversión. Se combina con bool. |
| fragment | Luz arcoíris `*`: sirve para cualquier color. Se puede repetir. |
| end | Frena la fila. Las fichas posteriores no emiten. |

Los modificadores empiezan de nuevo al pulsar VOLAR. Solo las primeras luces que pide el capullo cuentan; las sobrantes se ignoran. Etapa 1: true/false; etapa 2 añade loop/bool/not; etapa 3 añade fragment/end.

## Recorrido reproducible

- Prueba primero false, true y VOLAR: falla y permanece en capullo 1. Vacía la fila.
- Capullo 1: true, true → VOLAR. Abre el primero y desbloquea repetición, alternancia e inversión.
- Capullo 2: bool, true, loop → VOLAR. Produce verde, azul, verde, azul.
- Capullo 3: fragment, loop, loop, true → VOLAR. Siete comodines y una verde abren el jardín.
- Otra solución del tercero: true, false, false, true, true, false, bool, loop. Las primeras ocho luces coinciden; sobra una.
- Pulsa Otra vez. Comprueba: capullo 1 cerrado, fila vacía, 16 fichas originales, solo true/false disponibles. Repite true, true para confirmar una nueva partida.

## Compilar y comprobar

Desde PowerShell, usa `../tools/build.ps1 -ProjectPath <carpeta main> -Bundle`. El motor instalado y Bob se reutilizan. Logs en `../evidence`.

La opción `--config=garden.autotest=1` al ejecutar el EXE activa una prueba determinista en el motor que usa on_input con posiciones de clic, falla una vez, abre los tres capullos y reinicia. Termina con salida 0 y `GARDEN_ENGINE_TEST_PASS` si todo coincide. Esa prueba verifica controles por código; no equivale a mover físicamente el ratón ni a una inspección visual.

## Comprobaciones y límites

- Compilación y paquete Windows: comprobados con Defold 1.13.1.
- Reglas puras: 50 aserciones en Lua 5.1, Lua 5.4 y LuaJIT 2.1. Suite conservada en `tests/test_garden.lua`; se ejecutó en el auxiliar y se repitió desde el maestro.
- Motor: intento incorrecto, avance, victoria y reinicio comprobados; véanse logs de engine.
- Captura de la ventana: varios intentos devolvieron timeout. No se certifica inspección visual ni partida manual completa. Falta probar con un niño, medir duración y validar legibilidad en su pantalla.
- No hay sonido, guardado ni conexión con el juego principal. Solo ratón y ventana de 960×640; no se validó cambio de tamaño, mando ni pantalla táctil.
- Los avisos Protobuf/temporales de Bob se conservaron. El primer arranque en sandbox falló al inicializar el registro de crash del motor; la ejecución autorizada fuera de sandbox arrancó. La primera versión también usaba una API antigua y fue corregida antes de la validación final.
- Incidencia de proceso: el auxiliar de lógica instaló Lupa para pruebas pese a la restricción de paquetes. No forma parte del juego ni es necesario para abrirlo; se conserva su registro y se declara esta desviación en evidence/result.json.

TFO Normal: dos chats auxiliares nativos, uno para reglas y otro para plan de QA y revisión de integración. Selecciones observadas y resultados se conservan en `../evidence/tfo`. No se atribuye cuota semanal individual ni se puntúa calidad.
