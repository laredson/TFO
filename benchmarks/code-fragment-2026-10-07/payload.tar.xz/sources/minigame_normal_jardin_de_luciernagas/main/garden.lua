-- Pure Lua 5.1+ game rules. A loop adds THREE repetitions of the last emitter.
local garden = {}
local stock = { loop = 3, bool = 2, ["not"] = 2, ["true"] = 3,
    ["false"] = 3, ["end"] = 2, fragment = 1 }
local unlock_stage = { ["true"] = 1, ["false"] = 1, loop = 2, bool = 2,
    ["not"] = 2, fragment = 3, ["end"] = 3 }
local goals = {
    { "green", "green" },
    { "green", "blue", "green", "blue" },
    { "green", "blue", "blue", "green", "green", "blue", "blue", "green" },
}

function garden.new()
    local inventory = {}
    for word, count in pairs(stock) do inventory[word] = count end
    return { stage = 1, won = false, inventory = inventory }
end

function garden.unlocked(state, word)
    return unlock_stage[word] ~= nil and state.stage >= unlock_stage[word]
end

function garden.available(state, word, program)
    if not garden.unlocked(state, word) then return false end
    if program and #program >= 8 then return false end
    local used = 0
    for _, token in ipairs(program or {}) do
        if token == word then used = used + 1 end
    end
    return used < (state.inventory[word] or 0)
end

function garden.targets(state)
    local target = {}
    for i, color in ipairs(goals[state.stage] or {}) do target[i] = color end
    return target
end

local function compare(state, result)
    result.matched, result.mismatches = 0, {}
    for i, expected in ipairs(garden.targets(state)) do
        local actual = result.pulses[i]
        if actual == expected or actual == "rainbow" then
            result.matched = result.matched + 1
        else
            result.mismatches[#result.mismatches + 1] = {
                index = i, expected = expected, actual = actual,
                reason = actual == nil and "missing" or "color",
            }
        end
    end
    return result
end

local function validate(state, program)
    if type(program) ~= "table" then return "El programa debe ser una lista de fichas." end
    local length, keys = #program, 0
    for key in pairs(program) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 or key > length then
            return "Coloca las fichas en una lista continua, sin huecos."
        end
        keys = keys + 1
    end
    if keys ~= length then return "Coloca las fichas en una lista continua, sin huecos." end
    if length > 8 then return "Puedes colocar como máximo 8 fichas." end
    local used = {}
    for i = 1, length do
        local word = program[i]
        if type(word) ~= "string" or stock[word] == nil then
            return "Ficha desconocida en la posición " .. i .. "."
        end
        if not garden.unlocked(state, word) then
            return "La ficha '" .. word .. "' todavía no está desbloqueada."
        end
        used[word] = (used[word] or 0) + 1
        if used[word] > (state.inventory[word] or 0) then
            return "No quedan suficientes fichas '" .. word .. "'."
        end
    end
end

function garden.simulate(state, program)
    local result = { pulses = {}, trace = {} }
    result.error = validate(state, program)
    if result.error then return compare(state, result) end
    local inverted, alternating, phase, emitter = false, false, false, nil
    local function emit(word, step)
        local color = "rainbow"
        if word ~= "fragment" then
            local green = word == "true"
            if inverted then green = not green end
            if alternating and phase then green = not green end
            color = green and "green" or "blue"
        end
        result.pulses[#result.pulses + 1] = color
        step.pulses[#step.pulses + 1] = color
        if alternating then phase = not phase end
    end
    for i, word in ipairs(program) do
        local step = { index = i, word = word, pulses = {} }
        result.trace[#result.trace + 1] = step
        if word == "true" or word == "false" or word == "fragment" then
            emitter = word
            emit(word, step)
        elseif word == "not" then
            inverted = not inverted
        elseif word == "bool" then
            alternating = true
        elseif word == "loop" then
            if not emitter then
                result.error = "Coloca true, false o fragment antes de loop para repetir una luz."
                step.error = result.error
                break
            end
            for _ = 1, 3 do emit(emitter, step) end
        elseif word == "end" then
            step.stopped = true
            break
        end
    end
    return compare(state, result)
end

function garden.submit(state, program)
    local result = garden.simulate(state, program)
    result.success = not state.won and result.error == nil and
        result.matched == #garden.targets(state)
    if result.success then
        if state.stage < #goals then state.stage = state.stage + 1
        else state.won = true end
    end
    return result
end

return garden
