local garden = require("main.garden")
local assertions = 0
local function check(condition, message)
    assertions = assertions + 1
    assert(condition, message)
end
local function colors(result, expected)
    check(table.concat(result.pulses, ",") == expected, "Unexpected pulses: " .. table.concat(result.pulses, ","))
end
local function state(stage)
    local s = garden.new(); s.stage = stage or 1; return s
end
local s = state()
check(s.stage == 1 and s.won == false, "Initial state")
local stock = { loop=3, bool=2, ["not"]=2, ["true"]=3, ["false"]=3, ["end"]=2, fragment=1 }
local count = 0
for word, amount in pairs(s.inventory) do
    count = count + 1; check(stock[word] == amount, "Exact inventory: " .. word)
end
check(count == 7, "Only specified tokens")
s.inventory.loop = 0
check(state().inventory.loop == 3, "Independent inventory")
s = state()
check(garden.unlocked(s, "true") and garden.unlocked(s, "false"), "Stage 1 unlocks")
check(not garden.unlocked(s, "loop") and not garden.unlocked(s, "unknown"), "Locked/unknown tokens")
check(garden.available(s, "true", {"true", "true"}), "Remaining inventory")
check(not garden.available(s, "true", {"true", "true", "true"}), "Exhausted inventory")
check(not garden.available(s, "bool", {}), "Locked availability")
local target = garden.targets(s); target[1] = "blue"
check(garden.targets(s)[1] == "green", "Targets are copies")
local r = garden.simulate(s, {"true", "false"})
colors(r, "green,blue")
check(r.matched == 1 and #r.mismatches == 1, "Mismatch counts")
check(r.mismatches[1].index == 2 and r.mismatches[1].expected == "green" and r.mismatches[1].actual == "blue", "Mismatch detail")
check(s.stage == 1 and s.won == false and s.inventory["true"] == 3, "Simulation is pure")
r = garden.simulate(s, {})
check(r.matched == 0 and #r.mismatches == 2 and r.mismatches[1].reason == "missing", "Missing pulses")
for _, program in ipairs({{"loop"}, {"unknown"}, {"true","true","true","true"}, {"true","false","true","false","true","false","true","false","true"}, {[1]="true", [3]="true"}, {foo="true"}, {42}}) do
    r = garden.submit(s, program)
    check(type(r.error) == "string" and r.success == false and s.stage == 1, "Reject invalid input")
end
check(garden.simulate(s, "true").error ~= nil, "Reject non-list")
r = garden.submit(s, {"true", "true", "false"})
check(r.success and r.matched == 2 and s.stage == 2, "Prefix match advances stage")
check(garden.unlocked(s,"loop") and garden.unlocked(s,"bool") and garden.unlocked(s,"not") and not garden.unlocked(s,"fragment") and not garden.unlocked(s,"end"), "Stage 2 unlocks")
r = garden.simulate(s, {"bool", "loop"})
check(r.error ~= nil and #r.trace == 2 and r.trace[2].error == r.error, "Friendly orphan loop error")
colors(garden.simulate(s, {"true", "loop", "loop"}), "green,green,green,green,green,green,green")
colors(garden.simulate(s, {"not", "true", "not", "false"}), "blue,blue")
colors(garden.simulate(s, {"bool", "true", "bool", "true", "true"}), "green,blue,green")
colors(garden.simulate(s, {"bool", "not", "true", "loop"}), "blue,green,blue,green")
r = garden.submit(s, {"bool", "true", "loop"})
colors(r, "green,blue,green,blue")
check(r.success and s.stage == 3 and #r.trace == 3 and #r.trace[3].pulses == 3, "Stage 2 solution and trace")
check(garden.unlocked(s,"fragment") and garden.unlocked(s,"end"), "Stage 3 unlocks")
colors(garden.simulate(s, {"true", "end", "false"}), "green")
check(garden.simulate(s, {"true","end","false"}).trace[2].stopped == true, "End trace")
check(garden.simulate(s, {"end","fragment","fragment"}).error ~= nil, "Validate all tokens even after end")
colors(garden.simulate(s, {"bool","fragment","true"}), "rainbow,blue")
r = garden.simulate(s, {"fragment", "loop", "loop", "true"})
check(r.matched == 8 and #r.mismatches == 0, "Rainbow wildcard solution")
check(garden.simulate(s, {"fragment","fragment"}).error ~= nil, "Fragment stock")
check(not garden.available(s,"loop",{"true","false","false","true","true","false","bool","loop"}), "Eight-slot limit")
r = garden.submit(s, {"true", "false", "false", "true", "true", "false", "bool", "loop"})
colors(r, "green,blue,blue,green,green,blue,blue,green,blue")
check(r.success and s.stage == 3 and s.won and r.matched == 8, "Final solution ignores ninth pulse")
check(s.inventory["true"] == 3 and s.inventory.loop == 3, "Reusable inventory")
r = garden.submit(s, {"fragment", "loop", "loop", "true"})
check(not r.success and s.stage == 3 and s.won, "Won state is stable")
print("PASS: " .. assertions .. " assertions")

