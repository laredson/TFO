-- Reglas puras: no dependen de GUI, temporizadores ni APIs de Defold.
local M = {}

M.order = {"true", "false", "loop", "not", "bool", "end", "fragment"}
M.initial = {loop = 3, bool = 2, ["not"] = 2, ["true"] = 3,
    ["false"] = 3, ["end"] = 2, fragment = 1}

local function unlocked(...)
    local result = {}
    for _, word in ipairs({...}) do result[word] = true end
    return result
end

M.levels = {
    {name = "Dos rayos", hint = "true da sol; false da luna.",
        target = {"sun", "moon"}, unlocked = unlocked("true", "false"),
        solution = {"true", "false"}},
    {name = "Sol que se repite", hint = "loop repite el último pulso.",
        target = {"sun", "sun", "sun", "sun"}, unlocked = unlocked("true", "false", "loop"),
        solution = {"true", "loop", "loop", "loop"}},
    {name = "Cambio de color", hint = "not añade el color contrario al último.",
        target = {"moon", "moon", "sun", "sun"}, unlocked = unlocked("true", "false", "loop", "not"),
        solution = {"false", "loop", "not", "loop"}},
    {name = "Baile y descanso", hint = "bool añade contrario y mismo; end añade un descanso.",
        target = {"sun", "moon", "sun", "rest"}, unlocked = unlocked("true", "false", "loop", "not", "bool", "end"),
        solution = {"true", "bool", "end"}},
    {name = "La chispa especial", hint = "fragment crea una chispa arcoíris.",
        target = {"moon", "sun", "moon", "rest", "wild"}, unlocked = unlocked("true", "false", "loop", "not", "bool", "end", "fragment"),
        solution = {"false", "bool", "end", "fragment"}},
}

local function counts()
    local result = {}
    for _, word in ipairs(M.order) do result[word] = M.initial[word] end
    return result
end

local function inspect(recipe, levelIndex)
    local remaining = counts()
    local level = M.levels[levelIndex]
    if not level then return remaining, "Flor desconocida." end
    if type(recipe) ~= "table" then return remaining, "La receta debe ser una lista." end
    -- Rechaza listas con huecos, claves extra o valores no secuenciales.
    local size = 0
    for key in pairs(recipe) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return remaining, "La receta debe ser una lista seguida."
        end
        size = size + 1
    end
    for index = 1, size do
        if recipe[index] == nil then return remaining, "La receta debe ser una lista seguida." end
    end
    if size > 4 then return remaining, "El tren admite hasta 4 fichas." end
    for index = 1, size do
        local word = recipe[index]
        if type(word) ~= "string" or remaining[word] == nil then
            return remaining, "Ficha desconocida."
        end
        if not level.unlocked[word] then return remaining, "Esta ficha todavía está dormida." end
        if remaining[word] == 0 then return remaining, "No quedan copias de esa ficha." end
        remaining[word] = remaining[word] - 1
    end
    return remaining, nil, size
end

function M.evaluate(recipe, levelIndex)
    local remaining, err, size = inspect(recipe, levelIndex)
    local output = {}
    local function result(message)
        return {ok = message == nil, output = output, remaining = remaining, error = message}
    end
    if err then return result(err) end
    if size == 0 then return result("Añade una ficha al tren.") end
    for _, word in ipairs(recipe) do
        local last = output[#output]
        if word == "true" then output[#output + 1] = "sun"
        elseif word == "false" then output[#output + 1] = "moon"
        elseif word == "end" then output[#output + 1] = "rest"
        elseif word == "fragment" then output[#output + 1] = "wild"
        elseif word == "loop" then
            if not last then return result("loop necesita un pulso anterior.") end
            output[#output + 1] = last
        elseif word == "not" or word == "bool" then
            if last ~= "sun" and last ~= "moon" then
                return result(word .. " necesita un sol o una luna anterior.")
            end
            output[#output + 1] = last == "sun" and "moon" or "sun"
            if word == "bool" then output[#output + 1] = last end
        end
        if #output > 12 then return result("La receta produce demasiados pulsos (máximo 12).") end
    end
    return result(nil)
end

function M.matches(output, target)
    if type(output) ~= "table" or type(target) ~= "table" or #output ~= #target then return false end
    for index, requested in ipairs(target) do
        local pulse = output[index]
        if requested ~= "sun" and requested ~= "moon" and requested ~= "rest" and requested ~= "wild" then return false end
        if pulse ~= requested and not (pulse == "wild" and (requested == "sun" or requested == "moon")) then return false end
    end
    return true
end

function M.new()
    return {level = 1, recipe = {}, won = false}
end

function M.add(state, word)
    if state.won then return false, "El jardín ya está despierto. Reinicia para volver a jugar." end
    local candidate = {}
    for index, item in ipairs(state.recipe) do candidate[index] = item end
    if type(word) ~= "string" then return false, "Ficha desconocida." end
    candidate[#candidate + 1] = word
    local _, err = inspect(candidate, state.level)
    if err then return false, err end
    state.recipe[#state.recipe + 1] = word
    return true, nil
end

function M.undo(state)
    state.recipe[#state.recipe] = nil
end

function M.clear(state)
    state.recipe = {}
end

function M.submit(state)
    if state.won then return {valid = false, success = false, output = {}, error = "El jardín ya está despierto."} end
    local evaluated = M.evaluate(state.recipe, state.level)
    return {valid = evaluated.ok, success = evaluated.ok and M.matches(evaluated.output, M.levels[state.level].target),
        output = evaluated.output, error = evaluated.error}
end

-- La GUI llama advance después del feedback de una solución correcta.
function M.advance(state)
    if state.won then return end
    M.clear(state)
    if state.level < #M.levels then state.level = state.level + 1
    else state.won = true end
end

function M.reset(state)
    state.level, state.recipe, state.won = 1, {}, false
end

return M
