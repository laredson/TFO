components {
  id: "tap"
  component: "/audio/tap.sound"
}
components {
  id: "bloom"
  component: "/audio/bloom.sound"
}
components {
  id: "retry"
  component: "/audio/retry.sound"
}
