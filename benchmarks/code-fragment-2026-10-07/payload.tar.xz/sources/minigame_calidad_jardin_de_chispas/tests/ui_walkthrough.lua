-- Opt-in real-engine GUI test. One synthetic action per frame interval.
-- These are not physical OS clicks and do not certify visual layout.
local M={}
local garden=require 'main.garden'
local function eq(a,b,label) assert(a==b,label..': expected '..tostring(b)..', got '..tostring(a)) end
local function fresh(self)
 eq(self.state.level,1,'reset level') eq(self.state.won,false,'reset victory')
 eq(#self.state.recipe,0,'reset recipe') eq(self.running,false,'reset animation')
 for word,count in pairs(garden.initial) do eq(garden.evaluate({},1).remaining[word],count,'reset '..word) end
end
function M.start(self)
 self.qa={clock=0,input=nil}
 self.qa.thread=coroutine.create(function()
  local function tick() coroutine.yield() end
  local function click(action)
   for _,b in ipairs(self.buttons) do
    if b.action==action then
     local p=gui.get_position(b.node)
     self.qa.input(self,hash('touch'),{pressed=true,x=p.x,y=p.y})
     tick() return
    end
   end
   error('Missing GUI button '..action)
  end
  local function wait_animation() while self.running do tick() end end
  click('loop') eq(#self.state.recipe,0,'locked card rejected')
  click('true') eq(garden.evaluate(self.state.recipe,1).remaining['true'],2,'reserve inventory')
  click('undo') eq(#self.state.recipe,0,'undo')
  click('true') click('false') click('clear') eq(#self.state.recipe,0,'clear')
  click('true') click('submit') eq(self.running,true,'animation begins')
  wait_animation()
  eq(self.success,false,'wrong recipe fails') eq(self.state.level,1,'wrong recipe cannot advance')
  eq(#self.state.recipe,1,'failed recipe preserved') click('clear')
  for level=1,5 do
   for _,word in ipairs(garden.levels[level].solution) do click(word) end
   if level==2 then click('true') eq(#self.state.recipe,4,'fifth slot rejected') end
   click('submit') eq(self.running,true,'valid animation starts')
   local before=#self.state.recipe
   click('true') eq(#self.state.recipe,before,'input blocked during animation')
   wait_animation() eq(self.success,true,'flower '..level)
   print('GUI_TEST_FLOWER '..level..' passed=true')
   if level<5 then click('next'); eq(self.state.level,level+1,'advance'); eq(#self.state.recipe,0,'recipe reset') end
  end
  eq(self.state.won,true,'victory')
  for i=1,10 do tick(); eq(self.state.won,true,'persistent victory') end
  click('reset') fresh(self)
  click('true') click('false') click('submit')
  self.qa.input(self,hash('restart'),{pressed=true}); tick(); fresh(self)
  for i=1,20 do tick(); fresh(self) end
  print('GUI_TEST_SUCCESS flowers=5 retry=true buttons=true victory=true restart_button=true restart_during_animation=true')
  sys.exit(0)
 end)
 print('GUI_TEST_START synthetic_gui_events=true visual_review=false')
end
function M.update(self,dt,input)
 local qa=self.qa
 qa.clock=qa.clock+dt
 if qa.clock<.12 then return end
 qa.clock=0; qa.input=input
 if coroutine.status(qa.thread)=='dead' then return end
 local ok,err=coroutine.resume(qa.thread)
 if not ok then print('GUI_TEST_FAILURE '..tostring(err)); self.qa=nil; sys.exit(1) end
end
return M
