-- Desde la raíz del proyecto: lua tests/garden_test.lua
-- En Defold: require("tests.garden_test") desde init() de un script de prueba.
local garden = require("main.garden")
local assertions, recipesChecked, tests = 0, 0, 0

local function check(condition, message)
    assertions = assertions + 1
    assert(condition, message or "Comprobación fallida")
end

local function equal(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for key, value in pairs(a) do if not equal(value, b[key]) then return false end end
    for key in pairs(b) do if a[key] == nil then return false end end
    return true
end

local function same(a, b, message) check(equal(a, b), message) end
local function copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = copy(item) end
    return result
end
local function test(name, run)
    run()
    tests = tests + 1
    print("PASS " .. name)
end

local expectedCounts = {loop = 3, bool = 2, ["not"] = 2, ["true"] = 3,
    ["false"] = 3, ["end"] = 2, fragment = 1}
local expectedOrder = {"true", "false", "loop", "not", "bool", "end", "fragment"}
local expectedTargets = {
    {"sun", "moon"}, {"sun", "sun", "sun", "sun"},
    {"moon", "moon", "sun", "sun"}, {"sun", "moon", "sun", "rest"},
    {"moon", "sun", "moon", "rest", "wild"},
}
local expectedSolutions = {
    {"true", "false"}, {"true", "loop", "loop", "loop"},
    {"false", "loop", "not", "loop"}, {"true", "bool", "end"},
    {"false", "bool", "end", "fragment"},
}
local unlockAt = {["true"] = 1, ["false"] = 1, loop = 2, ["not"] = 3,
    bool = 4, ["end"] = 4, fragment = 5}

-- Oráculo independiente: reserva inventario y luego aplica transformaciones.
local function oracle(recipe, level)
    local remaining, output = copy(expectedCounts), {}
    for _, word in ipairs(recipe) do
        if unlockAt[word] > level or remaining[word] == 0 then return false end
        remaining[word] = remaining[word] - 1
    end
    if #recipe == 0 or #recipe > 4 then return false end
    for _, word in ipairs(recipe) do
        if word == "true" then table.insert(output, "sun")
        elseif word == "false" then table.insert(output, "moon")
        elseif word == "end" then table.insert(output, "rest")
        elseif word == "fragment" then table.insert(output, "wild")
        else
            local last = output[#output]
            if word == "loop" then
                if last == nil then return false end
                table.insert(output, last)
            else
                local opposite = ({sun = "moon", moon = "sun"})[last or ""]
                if not opposite then return false end
                table.insert(output, opposite)
                if word == "bool" then table.insert(output, last) end
            end
        end
    end
    if #output > 12 then return false end
    return true, output, remaining
end

test("Inventario exacto de 16 fichas y API de niveles", function()
    same(garden.order, expectedOrder)
    same(garden.initial, expectedCounts)
    local total = 0
    for _, quantity in pairs(garden.initial) do total = total + quantity end
    check(total == 16)
    check(#garden.levels == 5)
    for level, definition in ipairs(garden.levels) do
        same(definition.target, expectedTargets[level])
        same(definition.solution, expectedSolutions[level])
        check(type(definition.name) == "string" and #definition.name > 0)
        check(type(definition.hint) == "string" and #definition.hint > 0)
        for _, word in ipairs(expectedOrder) do
            check((definition.unlocked[word] == true) == (unlockAt[word] <= level), "Desbloqueo incorrecto")
        end
    end
end)

test("Transformaciones exactas de cada ficha", function()
    local cases = {
        {{"true"}, {"sun"}}, {{"false"}, {"moon"}},
        {{"true", "loop", "loop", "loop"}, {"sun", "sun", "sun", "sun"}},
        {{"false", "not"}, {"moon", "sun"}}, {{"true", "not"}, {"sun", "moon"}},
        {{"true", "bool"}, {"sun", "moon", "sun"}},
        {{"false", "bool"}, {"moon", "sun", "moon"}},
        {{"end", "loop"}, {"rest", "rest"}},
        {{"fragment", "loop", "loop"}, {"wild", "wild", "wild"}},
        {{"true", "bool", "bool", "loop"}, {"sun", "moon", "sun", "moon", "sun", "sun"}},
    }
    for _, case in ipairs(cases) do
        local result = garden.evaluate(case[1], 5)
        check(result.ok and result.error == nil)
        same(result.output, case[2])
    end
end)

test("Recetas inválidas y errores claros", function()
    local cases = {{}, {"loop"}, {"not"}, {"bool"}, {"end", "not"},
        {"end", "bool"}, {"fragment", "not"}, {"fragment", "bool"},
        {"end", "loop", "not"}, {"fragment", "loop", "bool"},
        {"true", "true", "true", "true"}, {"fragment", "fragment"},
        {"end", "end", "end"}, {"true", "false", "not", "not", "not"},
        {"unknown"}, {17}, {[2] = "true"}, {word = "true"}}
    for _, recipe in ipairs(cases) do
        local result = garden.evaluate(recipe, 5)
        check(not result.ok)
        check(type(result.error) == "string" and #result.error > 0)
        check(type(result.output) == "table" and type(result.remaining) == "table")
    end
    check(not garden.evaluate(nil, 1).ok)
    check(not garden.evaluate("true", 1).ok)
    check(not garden.evaluate({"true"}, 0).ok)
    check(not garden.evaluate({"true"}, 6).ok)
    for word, level in pairs(unlockAt) do
        if level > 1 then
            local result = garden.evaluate({"true", word}, level - 1)
            check(not result.ok and result.error ~= nil)
        end
    end
end)

test("Comparación exacta y comodín asimétrico", function()
    local pulses = {"sun", "moon", "rest", "wild"}
    for _, output in ipairs(pulses) do
        for _, target in ipairs(pulses) do
            local expected = output == target or (output == "wild" and (target == "sun" or target == "moon"))
            check(garden.matches({output}, {target}) == expected)
        end
    end
    check(garden.matches({}, {}))
    check(not garden.matches({"sun"}, {}))
    check(not garden.matches({"sun", "moon"}, {"sun"}))
    check(not garden.matches({"sun"}, {"sun", "moon"}))
    check(garden.matches({"wild", "wild", "rest", "wild"}, {"sun", "moon", "rest", "wild"}))
    check(not garden.matches({"wild"}, {"rest"}))
    check(not garden.matches({"sun"}, {"wild"}))
    check(not garden.matches({"moon"}, {"wild"}))
    check(not garden.matches({"unknown"}, {"unknown"}))
    check(not garden.matches(nil, {"sun"}))
end)

test("Añadir reserva copias, admite parciales y nunca muta al fallar", function()
    local state = garden.new()
    for _, word in ipairs({"loop", "not", "bool", "end", "fragment", "unknown"}) do
        local before = copy(state)
        local ok, err = garden.add(state, word)
        check(not ok and type(err) == "string")
        same(state, before)
    end
    for _ = 1, 3 do check(garden.add(state, "true")) end
    local before = copy(state)
    check(not garden.add(state, "true"))
    same(state, before)
    check(garden.add(state, "false"))
    before = copy(state)
    check(not garden.add(state, "false"))
    same(state, before)
    garden.undo(state)
    same(state.recipe, {"true", "true", "true"})
    garden.undo(state)
    check(garden.add(state, "true"))
    garden.clear(state)
    same(state.recipe, {})
    garden.undo(state)
    same(state.recipe, {})
    state.level = 2
    check(garden.add(state, "loop"), "Una receta parcial no se evalúa al añadir")
    local result = garden.submit(state)
    check(not result.valid and not result.success and result.error ~= nil)
    before = copy(state)
    check(not garden.add(state, nil))
    same(state, before)
    state.level = 5
    garden.clear(state)
    check(garden.add(state, "fragment"))
    before = copy(state)
    check(not garden.add(state, "fragment"))
    same(state, before)
end)

test("Enviar es repetible; victoria, avance y reinicio completos", function()
    local state, other = garden.new(), garden.new()
    check(state ~= other and state.recipe ~= other.recipe)
    local initial = garden.submit(state)
    check(not initial.valid and not initial.success)
    check(garden.add(state, "true"))
    local wrong = garden.submit(state)
    check(wrong.valid and not wrong.success and wrong.error == nil)
    check(state.level == 1 and not state.won)
    garden.clear(state)
    for level, solution in ipairs(expectedSolutions) do
        check(state.level == level and not state.won)
        for _, word in ipairs(solution) do check(garden.add(state, word)) end
        local before = copy(state)
        local first, retry = garden.submit(state), garden.submit(state)
        check(first.valid and first.success and first.error == nil)
        same(first.output, expectedTargets[level])
        same(first, retry)
        same(state, before, "submit no debe avanzar ni consumir el inventario")
        garden.advance(state)
        same(state.recipe, {})
    end
    check(state.level == 5 and state.won)
    local before = copy(state)
    garden.advance(state)
    same(state, before)
    check(not garden.add(state, "true"))
    check(not garden.submit(state).valid)
    garden.reset(state)
    same(state, {level = 1, recipe = {}, won = false})
    same(other, garden.new())
    for _, word in ipairs(expectedSolutions[1]) do check(garden.add(state, word)) end
    check(garden.submit(state).success)
    garden.reset(state)
    same(garden.evaluate(state.recipe, state.level).remaining, expectedCounts)
end)

test("Resultados independientes sin alias del inventario", function()
    local original = copy(garden.initial)
    local result = garden.evaluate({"true"}, 1)
    result.remaining["true"] = 999
    result.output[1] = "wild"
    same(garden.initial, original)
    same(garden.evaluate({}, 1).remaining, expectedCounts)
    same(garden.evaluate({"true"}, 1).output, {"sun"})
end)

test("Todas las 14005 recetas de longitud 0 a 4 en cinco niveles", function()
    local maxOutput, successes = 0, {0, 0, 0, 0, 0}
    local function enumerate(recipe)
        for level = 1, 5 do
            recipesChecked = recipesChecked + 1
            local before = copy(recipe)
            local expectedValid, expectedOutput, expectedRemaining = oracle(recipe, level)
            local result = garden.evaluate(recipe, level)
            check(result.ok == expectedValid, "Validez discrepante en nivel " .. level)
            same(recipe, before, "evaluate mutó su entrada")
            check(#result.output <= 12)
            if expectedValid then
                check(result.error == nil)
                same(result.output, expectedOutput, "Transformación discrepante")
                same(result.remaining, expectedRemaining, "Inventario discrepante")
                maxOutput = math.max(maxOutput, #result.output)
                if garden.matches(result.output, expectedTargets[level]) then successes[level] = successes[level] + 1 end
            else check(type(result.error) == "string") end
        end
        if #recipe < 4 then
            for _, word in ipairs(expectedOrder) do
                recipe[#recipe + 1] = word
                enumerate(recipe)
                recipe[#recipe] = nil
            end
        end
    end
    enumerate({})
    check(recipesChecked == 14005)
    check(maxOutput == 6, "Con cuatro fichas y dos bool el máximo alcanzable es seis")
    for level = 1, 5 do check(successes[level] > 0, "Flor sin solución") end
end)

local report = {passed = true, tests = tests, assertions = assertions, recipes = recipesChecked}
print("GARDEN_TEST_SUCCESS tests=" .. tests .. " assertions=" .. assertions .. " recipes=" .. recipesChecked)
return report
