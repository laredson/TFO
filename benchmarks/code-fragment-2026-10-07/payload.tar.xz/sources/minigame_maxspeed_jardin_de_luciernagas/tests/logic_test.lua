package.path = "./?.lua;./?/init.lua;" .. package.path
local L = require "main.logic"
local inventory = require "main.inventory"
local passed = 0
local function eq(actual, expected, label)
    assert(actual == expected, (label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
end
local function list(actual, expected)
    eq(#actual, #expected, "length")
    for i = 1, #expected do eq(actual[i], expected[i], "item " .. i) end
end
local function test(name, fn)
    fn()
    passed = passed + 1
    print("PASS " .. name)
end
local function full_inventory(state)
    local expected = { loop = 3, bool = 2, ["not"] = 2, ["true"] = 3, ["false"] = 3, ["end"] = 2, fragment = 1 }
    local sum = 0
    for word, amount in pairs(expected) do eq(state.available[word], amount, word); sum = sum + amount end
    eq(sum, 16)
end
local function add_all(state, sequence)
    for _, word in ipairs(sequence) do local ok, message = L.add(state, word); assert(ok, message) end
end

test("original inventory and fresh state", function()
    eq(#inventory, 16)
    local state = L.new()
    full_inventory(state)
    eq(state.stage, 1); eq(state.won, false); eq(state.attempts, 0)
    list(state.sequence, {}); list(state.output, {})
end)

test("all five solutions through real add submit advance progression", function()
    local state = L.new()
    for stage = 1, 5 do
        eq(state.stage, stage)
        local sequence = L.solution(stage)
        assert(#sequence <= 10)
        add_all(state, sequence)
        list(state.output, L.orders[stage].target)
        local result = L.submit(state)
        eq(result.success, true); eq(result.stage, stage); eq(result.won, stage == 5)
        eq(result.mismatch, nil); eq(state.stage, stage); eq(state.won, false)
        list(state.sequence, sequence) -- submit keeps animation data in place.
        assert(L.advance(state, result))
        list(state.sequence, {}); list(state.output, {}); full_inventory(state)
        list(result.output, L.orders[stage].target) -- snapshot survives clear.
        eq(state.completed[stage], true)
        eq(L.advance(state, result), false) -- duplicate animation callback.
    end
    eq(state.attempts, 5); eq(state.won, true); eq(state.stage, 5)
    eq(L.add(state, "true"), false)
    L.reset(state)
    eq(state.stage, 1); eq(state.won, false); eq(state.attempts, 0)
    eq(next(state.completed), nil); full_inventory(state)
end)

test("seed group boundaries and two copies of last bug", function()
    list(L.evaluate({"true", "loop", "false", "loop", "not"}), {"s", "s", "s", "s", "s", "s"})
    list(L.evaluate({"false", "loop", "true", "loop", "bool"}), {"m", "m", "m", "s", "m", "s"})
    list(L.evaluate({"true", "loop", "bool", "loop"}), {"s", "m", "s", "s", "s"})
    list(L.evaluate({"false", "loop", "bool", "loop"}), {"m", "s", "m", "m", "m"})
end)

test("rainbow survives not bool and copies", function()
    list(L.evaluate({"fragment", "loop", "not", "bool"}), {"r", "r", "r"})
    list(L.evaluate({"true", "loop", "fragment", "not", "bool"}), {"s", "s", "s", "r"})
end)

test("scissors adjust current group including previous group", function()
    list(L.evaluate({"true", "loop", "bool", "end", "loop"}), {"s", "m", "m", "m"})
    list(L.evaluate({"true", "loop", "false", "end", "not"}), {"m", "m", "m"})
    local output, events = L.evaluate({"true", "end", "loop"})
    list(output, {}); eq(events[3].valid, false); eq(events[3].code, "no_group")
end)

test("all four operators without group report recoverable feedback", function()
    for _, word in ipairs({"loop", "not", "bool", "end"}) do
        local output, events = L.evaluate({word})
        list(output, {}); eq(#events, 1); eq(events[1].word, word)
        eq(events[1].valid, false); eq(events[1].code, "no_group")
        assert(#events[1].message > 0)
        local state = L.new(); state.stage = 5
        local original = state.available[word]
        assert(L.add(state, word)); eq(state.available[word], original - 1)
        local result = L.submit(state); eq(result.success, false)
        assert(L.advance(state, result)); full_inventory(state)
        add_all(state, L.solution(5)); eq(L.submit(state).success, true)
    end
end)

test("tool unlocks are cumulative and enforced", function()
    local stages = { ["true"] = 1, ["false"] = 1, loop = 2, ["not"] = 2, bool = 3, ["end"] = 4, fragment = 5 }
    for stage = 1, 5 do
        for word, unlock in pairs(stages) do
            local state = L.new(); state.stage = stage
            eq(L.orders[stage].unlocked[word] == true, stage >= unlock)
            eq(L.add(state, word), stage >= unlock, "unlock " .. word)
            if stage < unlock then full_inventory(state); eq(#state.sequence, 0) end
        end
    end
end)

test("inventory exhaustion undo clear and isolation", function()
    local state = L.new()
    add_all(state, {"true", "true", "true"})
    eq(state.available["true"], 0); eq(L.add(state, "true"), false)
    eq(#state.sequence, 3); assert(L.undo(state)); eq(state.available["true"], 1)
    list(state.output, {"s", "s"}); assert(L.clear(state)); full_inventory(state)
    eq(L.undo(state), false)
    local other = L.new(); L.add(state, "false"); full_inventory(other)
    local solution = L.solution(1); solution[1] = "false"
    list(L.solution(1), {"true"})
end)

test("ten tile machine rejects eleventh without consuming", function()
    local state = L.new(); state.stage = 5
    add_all(state, {"true", "true", "true", "false", "false", "false", "not", "not", "bool", "bool"})
    eq(#state.sequence, 10); eq(L.add(state, "end"), false); eq(state.available["end"], 2)
    local output, events = L.evaluate({"true", "true", "true", "false", "false", "false", "not", "not", "bool", "bool", "fragment"})
    eq(#output, 6); eq(events[11].code, "tile_limit"); eq(events[11].valid, false)
end)

test("twelve bug boundary and atomic overflow rejection", function()
    local state = L.new(); state.stage = 5
    add_all(state, {"true", "loop", "loop", "loop", "true", "true", "false", "false", "false"})
    eq(#state.output, 12); eq(#state.sequence, 9)
    eq(L.add(state, "fragment"), false); eq(state.available.fragment, 1); eq(#state.sequence, 9)
    assert(L.add(state, "end")); eq(#state.output, 11)
    assert(L.undo(state)); eq(#state.output, 12)
    -- Direct evaluator also enforces cap even for input exceeding inventory.
    local output, events = L.evaluate({"true", "loop", "loop", "loop", "loop", "loop", "loop"})
    eq(#output, 11); eq(events[7].valid, false); eq(events[7].code, "bug_limit")
end)

test("wrong shape missing bug extra bug and empty mismatch", function()
    for _, case in ipairs({ {seq = {}, mismatch = 1}, {seq = {"false"}, mismatch = 1}, {seq = {"true", "true"}, mismatch = 2} }) do
        local state = L.new(); add_all(state, case.seq)
        local result = L.submit(state)
        eq(result.success, false); eq(result.won, false); eq(result.mismatch, case.mismatch)
        eq(state.attempts, 1); list(state.sequence, case.seq)
        assert(L.advance(state, result)); eq(state.stage, 1); full_inventory(state)
        eq(next(state.completed), nil)
    end
    local state = L.new(); state.stage = 2; add_all(state, {"false"})
    eq(L.submit(state).mismatch, 2)
end)

test("result snapshots edits and reset invalidate stale advance", function()
    local state = L.new(); L.add(state, "true")
    local result = L.submit(state)
    result.output[1] = "m"; result.target[1] = "m"
    eq(state.output[1], "s"); eq(L.orders[1].target[1], "s")
    L.undo(state); eq(L.advance(state, result), false); eq(state.stage, 1)
    L.add(state, "true"); result = L.submit(state)
    local same = L.reset(state); eq(same, state); eq(L.advance(state, result), false)
    full_inventory(state); list(state.sequence, {}); list(state.output, {})
end)

test("unknown words rejected and evaluator reports invalid event", function()
    local state = L.new(); eq(L.add(state, "banana"), false); full_inventory(state)
    local output, events = L.evaluate({"banana", "true"})
    list(output, {"s"}); eq(events[1].valid, false); eq(events[1].code, "unknown")
    eq(events[2].valid, true)
end)

print("ALL PASSED: " .. passed .. " test groups")
