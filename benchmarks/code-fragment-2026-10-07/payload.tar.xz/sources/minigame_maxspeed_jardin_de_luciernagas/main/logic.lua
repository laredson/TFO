-- Pure garden rules. No Defold globals, clocks, input, or rendering dependencies.
local inventory = require "main.inventory"
local L = { MAX_TILES = 10, MAX_BUGS = 12 }

local function copy(list)
    local result = {}
    for i, value in ipairs(list) do result[i] = value end
    return result
end

local function counts()
    local result = {}
    for _, word in ipairs(inventory) do result[word] = (result[word] or 0) + 1 end
    return result
end

local function tools(words)
    local result = {}
    for _, word in ipairs(words) do result[word] = true end
    return result
end

L.orders = {
    { target = {"s"}, title = "Un rayito de sol", hint = "true trae un sol.",
      unlocked = tools({"true", "false"}) },
    { target = {"m", "m", "m"}, title = "Tres lunas amigas", hint = "loop trae dos amigos. not cambia sol y luna.",
      unlocked = tools({"true", "false", "loop", "not"}) },
    { target = {"s", "m", "s"}, title = "Sol, luna, sol", hint = "bool ordena un grupo: sol, luna, sol...",
      unlocked = tools({"true", "false", "loop", "not", "bool"}) },
    { target = {"m", "s"}, title = "Una pareja brillante", hint = "end corta el ultimo bichito.",
      unlocked = tools({"true", "false", "loop", "not", "bool", "end"}) },
    { target = {"m", "s", "m", "r", "s", "m", "s", "m", "s"}, title = "El jardin de luciernagas",
      hint = "Tres lunas con bool, fragment, y cinco soles con bool.",
      unlocked = tools({"true", "false", "loop", "not", "bool", "end", "fragment"}) }
}

local seeds = { ["true"] = "s", ["false"] = "m", fragment = "r" }
local operators = { loop = true, ["not"] = true, bool = true, ["end"] = true }
local function flip(value) return value == "s" and "m" or value == "m" and "s" or value end

function L.evaluate(sequence)
    local output, groups, events = {}, {}, {}
    local next_group = 0
    for index, word in ipairs(sequence) do
        local event = { word = word, message = "", valid = true, index = index }
        local group = groups[#groups]
        if index > L.MAX_TILES then
            event.valid, event.code, event.message = false, "tile_limit", "La maquina admite 10 fichas."
        elseif seeds[word] then
            if #output >= L.MAX_BUGS then
                event.valid, event.code, event.message = false, "bug_limit", "Solo caben 12 bichitos."
            else
                next_group = next_group + 1
                output[#output + 1], groups[#groups + 1] = seeds[word], next_group
                event.message = word == "true" and "Llega un sol." or word == "false" and "Llega una luna." or "Llega un arcoiris."
            end
        elseif not operators[word] then
            event.valid, event.code, event.message = false, "unknown", "Esa ficha no existe."
        elseif not group then
            event.valid, event.code, event.message = false, "no_group", "Pon primero true, false o fragment."
        elseif word == "loop" then
            if #output + 2 > L.MAX_BUGS then
                event.valid, event.code, event.message = false, "bug_limit", "No caben dos amigos mas: maximo 12."
            else
                local last = output[#output]
                for _ = 1, 2 do
                    output[#output + 1], groups[#groups + 1] = last, group
                end
                event.message = "Llegan dos amigos iguales."
            end
        elseif word == "end" then
            table.remove(output)
            table.remove(groups)
            event.message = "Cortaste el ultimo bichito."
        else
            local first = #groups
            while first > 1 and groups[first - 1] == group do first = first - 1 end
            if word == "not" then
                for i = first, #output do output[i] = flip(output[i]) end
                event.message = "Este grupo cambia sol y luna."
            else
                local color = output[first]
                for i = first, #output do
                    if output[i] ~= "r" then
                        output[i] = color
                        color = flip(color)
                    end
                end
                event.message = "Este grupo alterna sol y luna."
            end
        end
        event.output_index = #output
        events[#events + 1] = event
    end
    -- Optional group IDs let the console show which family a tool will change.
    return output, events, groups
end

function L.new()
    return { stage = 1, won = false, sequence = {}, output = {}, events = {},
        available = counts(), attempts = 0, completed = {}, last_result = nil }
end

local function recalculate(state)
    state.available = counts()
    for _, word in ipairs(state.sequence) do state.available[word] = state.available[word] - 1 end
    state.output, state.events = L.evaluate(state.sequence)
    state.last_result = nil
end

function L.add(state, word)
    if state.won then return false, "El jardin esta completo. Pulsa Otra vez." end
    if not state.available[word] then return false, "Esa ficha no existe." end
    if not L.orders[state.stage].unlocked[word] then return false, "Esta ficha tiene candado." end
    if #state.sequence >= L.MAX_TILES then return false, "La maquina admite 10 fichas." end
    if state.available[word] <= 0 then return false, "Ya usaste todas esas fichas. Deshaz o limpia." end
    local candidate = copy(state.sequence)
    candidate[#candidate + 1] = word
    local _, events = L.evaluate(candidate)
    local event = events[#events]
    if event.code == "bug_limit" then return false, event.message end
    state.sequence = candidate
    recalculate(state)
    -- An operator without a group is allowed in the machine and gives feedback.
    -- Undo/clear/advance return its tile, so the mistake never costs it permanently.
    return true, event.message
end

function L.undo(state)
    if #state.sequence == 0 then return false, "La maquina ya esta vacia." end
    table.remove(state.sequence)
    recalculate(state)
    return true, "Ficha devuelta."
end

function L.clear(state)
    state.sequence = {}
    recalculate(state)
    return true, "Maquina limpia. Todas las fichas vuelven."
end

function L.submit(state)
    local order = L.orders[state.stage]
    local mismatch
    for i = 1, math.max(#state.output, #order.target) do
        if state.output[i] ~= order.target[i] then mismatch = i; break end
    end
    state.attempts = state.attempts + 1
    local success = mismatch == nil and not state.won
    local result = { success = success, won = success and state.stage == #L.orders,
        stage = state.stage, output = copy(state.output), target = copy(order.target),
        mismatch = mismatch, attempt = state.attempts,
        message = success and "Pedido listo!" or "Mira el bichito marcado e intenta otra vez." }
    state.last_result = result
    return result
end

function L.advance(state, result)
    -- Avoid advancing twice or applying an animation result after editing/resetting.
    if result ~= state.last_result or result.stage ~= state.stage then return false end
    if result.success and not state.won then
        state.completed[state.stage] = true
        if state.stage == #L.orders then state.won = true else state.stage = state.stage + 1 end
    end
    L.clear(state)
    return true
end

function L.reset(state)
    local fresh = L.new()
    for key in pairs(state) do state[key] = nil end
    for key, value in pairs(fresh) do state[key] = value end
    return state
end

local solutions = {
    {"true"},
    {"true", "loop", "not"},
    {"true", "loop", "bool"},
    {"false", "loop", "bool", "end"},
    {"false", "loop", "bool", "fragment", "true", "loop", "loop", "bool"}
}

function L.solution(stage) return copy(solutions[stage] or {}) end

return L
