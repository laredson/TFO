# Jardín de luciérnagas

Minijuego independiente para una consola de Code Fragment. Llena los cinco pedidos del jardín fabricando bichitos de sol, luna y arcoíris. No necesitas saber programar: pulsa fichas y observa qué cambia. La partida está diseñada para unos 2–3 minutos de exploración, sin límite de tiempo ni pérdida permanente de fichas.

## Abrir y ejecutar

- Proyecto: abre `game.project` con Defold 1.13.1 y ejecuta con **Project > Build**.
- Windows: abre el ejecutable de la carpeta `dist`. Mantén junto a él los archivos de datos y DLL que contiene esa carpeta.
- Para reconstruir con la instalación proporcionada: `& '..\tools\build.ps1' -ProjectPath $PWD -Bundle` desde esta carpeta.

## Jugar

Pulsa una ficha para ponerla en la máquina. La fila de bichitos muestra el resultado al instante; compárala con los nidos pedidos. Pulsa **Probar** (o espacio) para enviarlos. **Deshacer** quita la última ficha y **Limpiar** devuelve todas. **Ayuda** muestra un ejemplo/pista. Pulsa **R** para reiniciar desde cualquier pedido; tras ganar, pulsa **Otra vez**.

Las fichas con candado se abren al completar pedidos. Todas las palabras y las cantidades iniciales se conservan: **loop ×3, bool ×2, not ×2, true ×3, false ×3, end ×2 y fragment ×1: 16 fichas**. Se prestan a la máquina y se devuelven al probar, limpiar o reiniciar. Puedes usar hasta diez fichas en un intento y producir hasta doce bichitos.

| Ficha | Efecto visible |
| --- | --- |
| true | Añade un sol y empieza un grupo. |
| false | Añade una luna y empieza un grupo. |
| loop | Añade dos copias del último bichito al grupo actual. |
| not | Cambia soles por lunas y lunas por soles en el grupo actual. |
| bool | Alterna sol/luna dentro del grupo actual a partir del primer bichito. |
| end | Corta el último bichito como una tijera. |
| fragment | Añade un arcoíris y empieza un grupo. |

Un grupo empieza con una semilla (`true`, `false` o `fragment`). Las herramientas actúan sobre ese grupo; una nueva semilla empieza otro. El arcoíris mantiene su forma al invertir/alternar. Si pruebas un pedido equivocado, verás dónde difiere y podrás intentarlo de nuevo. No se consumen fichas.

## Recorrido reproducible

En cada fila, pulsa las fichas en el orden indicado y luego **Probar**. Espera a que termine el envío antes del siguiente pedido.

1. `true` → un sol.
2. `true`, `loop`, `not` → tres lunas. Otra manera: `false`, `loop`.
3. `true`, `loop`, `bool` → sol, luna, sol.
4. `false`, `loop`, `bool`, `end` → luna, sol.
5. `false`, `loop`, `bool`, `fragment`, `true`, `loop`, `loop`, `bool` → luna, sol, luna, arcoíris, sol, luna, sol, luna, sol.

Comprueba la celebración y el jardín completo. Pulsa **Otra vez** y verifica pedido 1, máquina vacía y las 16 fichas disponibles con sus cantidades originales. También puedes reiniciar con **R**. Para comprobar un error: en pedido 1, elige `false` y **Probar**; permanece el pedido 1 y las fichas regresan.

## Comprobaciones y limitaciones

Resultados y registros completos: `../evidence/result.json`.

- Compilación y paquete Windows con Defold 1.13.1: salida 0.
- Reglas ejecutadas con LuaJIT incluido en Defold: 13 grupos aprobados.
- Recorrido en el motor real con la GUI, sonidos y reglas finales: 178 comprobaciones aprobadas. Incluye el error inicial, devolución de fichas, ayuda, deshacer/limpiar, los cinco pedidos, desbloqueos, victoria, Otra vez y R durante una animación. Las entradas se inyectaron en `on_input` en una copia aislada; no es una partida manual. El ejecutable entregado no contiene el controlador de pruebas.
- Se corrigió la reserva de nodos GUI después de detectar un desbordamiento al reconstruir varias ayudas en el mismo instante. La repetición completa pasó con una reserva de 4096 y menos de 2048 nodos vivos en los estados comprobados.
- La captura de Windows mediante Computer Use falló dos veces, incluida su recuperación. La inspección visual manual, el uso de ratón físico y la legibilidad final en pantalla no quedaron certificados. Los dibujos de prueba del auxiliar son simulaciones y no se presentan como capturas de Defold.
- El motor falló al arrancar dentro del aislamiento restrictivo de la herramienta. Fuera de ese aislamiento abrió su ventana e hizo el recorrido real correctamente. Los registros de ambas situaciones se conservan.
- TFO coordinó dos chats auxiliares. El error global del host interrumpió el auxiliar de escena; se integraron sus fuentes existentes. El flujo `flow_muy3ikhl_60daab1ad6` quedó en `needs_review`, y sus operaciones de recuperación/reconciliación fueron rechazadas. No se declara cerrado ni se han reenviado tareas inciertas. Hay registros y mediciones parciales en evidence.

La partida está diseñada para 2–3 minutos de exploración; esa duración no se ha medido con niños. La comprensión y la diversión infantil requieren evaluación humana. El prototipo todavía no se conecta con el juego principal.
