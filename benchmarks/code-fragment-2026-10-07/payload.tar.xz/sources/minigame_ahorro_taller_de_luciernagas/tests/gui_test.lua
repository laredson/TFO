-- Small Defold GUI adapter to execute real callbacks without a graphics driver.
local nodes={}
vmath={vector3=function(x,y,z) return {x=x,y=y,z=z} end,vector4=function(...) return {...} end}
hash=function(s) return s end
msg={post=function() end}
sys={get_config_string=function(_,d) return d end}
gui={animate=function() end}
local function node(p,s) local n={p=p,s=s}; nodes[#nodes+1]=n; return n end
gui.new_box_node=node
gui.new_pie_node=node
gui.new_text_node=function(p,text) local n=node(p,{x=0,y=0}); n.text=text; return n end
gui.set_text=function(n,t) n.text=t end
gui.set_color=function(n,c) n.color=c end
gui.set_font=function() end
gui.set_scale=function() end
gui.set_perimeter_vertices=function() end
gui.set_pie_perimeter_vertices=function() end
gui.delete_node=function(n) n.deleted=true end
gui.pick_node=function(n,x,y) return math.abs(x-n.p.x)<=n.s.x/2 and math.abs(y-n.p.y)<=n.s.y/2 end
dofile("main/game.gui_script")
local state={}
init(state)
local function click(x,y) on_input(state,"touch",{pressed=true,x=x,y=y}) end
assert(state.stage==1 and #state.selected==0)
click(80,166) -- locked loop
assert(#state.selected==0)
click(878,166) -- true
assert(#state.selected==1)
click(878,166) -- no duplicate physical tile
assert(#state.selected==1)
click(165,319) -- remove from row
assert(#state.selected==0)
click(730,270) -- recoverable wrong send
assert(state.stage==1)
click(878,166); click(730,270)
assert(state.stage==2 and #state.selected==0)
click(308,90); click(422,166); click(80,166); click(194,166)
assert(#state.selected==4)
click(730,270)
assert(state.stage==3 and #state.selected==0)
click(878,90); click(80,166); click(650,90); click(730,270)
assert(state.stage==4 and #state.selected==0)
click(878,90); click(730,270)
assert(state.stage==4 and #state.selected==1)
click(868,270)
assert(#state.selected==0)
click(830,29)
assert(state.stage==1 and #state.selected==0)
update(state,.016)
local live=0
for _,n in ipairs(nodes) do if not n.deleted then live=live+1 end end
assert(live<512)
print("GUI CALLBACK TESTS PASSED: real click coordinates, locks, duplicate prevention, remove, error, three advances, victory sandbox, clear, restart, node limit")




