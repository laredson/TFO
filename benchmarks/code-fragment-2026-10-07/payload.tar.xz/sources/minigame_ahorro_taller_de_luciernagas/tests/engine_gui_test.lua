local M={}
local steps={
 {80,166,1,0},{878,166,1,1},{878,166,1,1},{165,319,1,0},
 {730,270,1,0},{878,166,1,1},{730,270,2,0},
 {308,90,2,1},{422,166,2,2},{80,166,2,3},{194,166,2,4},{730,270,3,0},
 {878,90,3,1},{80,166,3,2},{650,90,3,3},{730,270,4,0},
 {878,90,4,1},{730,270,4,1},{868,270,4,0},{830,29,1,0}
}
function M.step(state,input)
 state.test_step=(state.test_step or 0)+1
 local s=steps[state.test_step]
 if not s then print("ENGINE GUI TESTS PASSED: real nodes/picking, locks, duplicates, remove, error, three flowers, victory, clear, restart");sys.exit(0);return end
 input(state,hash("touch"),{pressed=true,x=s[1],y=s[2]})
 assert(state.stage==s[3] and #state.selected==s[4],"step "..state.test_step)
end
return M
