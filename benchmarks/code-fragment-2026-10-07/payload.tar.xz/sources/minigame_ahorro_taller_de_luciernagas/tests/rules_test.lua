local r=require "main.rules"
local M={}
function M.run()
    assert(#r.inventory==16)
    local counts={}
    for _,v in ipairs(r.inventory) do counts[v]=(counts[v] or 0)+1 end
    assert(counts.loop==3 and counts.bool==2 and counts["not"]==2 and counts["true"]==3 and counts["false"]==3 and counts["end"]==2 and counts.fragment==1)
    assert(r.matches(r.evaluate({"true"}),1))
    assert(r.matches(r.evaluate({"false","bool","loop","loop"}),2))
    assert(r.matches(r.evaluate({"fragment","loop","end","false"}),3))
    assert(r.matches(r.evaluate({"false","not"}),1))
    assert(not r.matches(r.evaluate({"true","true"}),1))
    assert(r.evaluate({"loop"})==nil)
    assert(r.evaluate({"bool"})==nil)
    assert(r.evaluate({"not"})==nil)
    local sel={}
    assert(not r.select(sel,1,1))
    assert(r.select(sel,8,1))
    assert(not r.select(sel,8,1))
    assert(#sel==1 and r.words(sel)[1]=="true")
    assert(r.unlocked("fragment",3) and not r.unlocked("fragment",2))
    print("TESTS PASSED: inventory, three solutions, inversion, stop, errors, locks, reuse")
end
return M
