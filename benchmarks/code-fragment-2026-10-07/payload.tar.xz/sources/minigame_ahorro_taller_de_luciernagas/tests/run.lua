require("tests.rules_test").run()
