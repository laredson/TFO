return {"loop", "loop", "loop", "bool", "bool", "not", "not", "true", "true", "true", "false", "false", "false", "end", "end", "fragment"}
