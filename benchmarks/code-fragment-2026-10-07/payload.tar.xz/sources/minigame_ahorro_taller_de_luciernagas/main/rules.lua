local M = {}
M.inventory = require "main.inventory"
M.targets = {{"Y"}, {"B","Y","B"}, {"R","R"}}
M.names = {Y="amarillo", B="azul", R="arcoiris"}
function M.unlocked(word, stage)
    return stage >= 3 or word == "true" or word == "false" or
        (stage >= 2 and (word == "not" or word == "bool" or word == "loop"))
end
function M.evaluate(words)
    local lights, color, alternating = {}, "Y", false
    for _,word in ipairs(words) do
        if word == "end" then break
        elseif word == "true" then color="Y"; lights[#lights+1]=color
        elseif word == "false" then color="B"; lights[#lights+1]=color
        elseif word == "fragment" then color="R"; lights[#lights+1]=color
        elseif word == "not" then
            if #lights == 0 then return nil,"Pon una luz antes de not." end
            color = lights[#lights] == "Y" and "B" or lights[#lights] == "B" and "Y" or "R"
            lights[#lights]=color
        elseif word == "bool" then
            if #lights == 0 then return nil,"Pon una luz antes de bool." end
            alternating = not alternating
        elseif word == "loop" then
            if #lights == 0 then return nil,"Pon una luz antes de loop." end
            if alternating and color ~= "R" then color = color=="Y" and "B" or "Y" end
            lights[#lights+1]=color
        end
    end
    return lights
end
function M.matches(lights, stage)
    local target=M.targets[stage]
    if not lights or not target or #lights ~= #target then return false end
    for i,v in ipairs(target) do if lights[i] ~= v then return false end end
    return true
end
function M.select(selected, index, stage)
    if #selected >= 8 then return false,"La fila tiene 8 lugares. Quita una ficha." end
    if not M.unlocked(M.inventory[index],stage) then return false,"Esta ficha despierta al regar otra flor." end
    for _,i in ipairs(selected) do if i==index then return false,"Esa ficha ya esta en tu fila." end end
    selected[#selected+1]=index
    return true
end
function M.words(selected)
    local words={}
    for _,i in ipairs(selected) do words[#words+1]=M.inventory[i] end
    return words
end
return M
