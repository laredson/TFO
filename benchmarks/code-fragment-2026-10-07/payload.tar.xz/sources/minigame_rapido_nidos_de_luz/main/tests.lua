-- From the worker root: lua tests.lua (Lua 5.1+, including LuaJIT).
local puzzle = require("main.puzzle")
local passed = 0
local function check(condition, label)
    assert(condition, label)
    passed = passed + 1
end
local function lights(words, expected)
    local pulses, err = puzzle.evaluate(words)
    check(err == nil and table.concat(pulses or {}) == expected,
        "evaluate: " .. table.concat(words, ",") .. " -> " .. expected)
end

check(#puzzle.inventory == 16, "original inventory has 16 tiles")
local expected_stock = { loop = 3, bool = 2, ["not"] = 2,
    ["true"] = 3, ["false"] = 3, ["end"] = 2, fragment = 1 }
for word, amount in pairs(expected_stock) do
    check(puzzle.stock[word] == amount, "stock: " .. word)
end
for stage = 1, 4 do
    for word in pairs(expected_stock) do
        local expected = word == "true" or word == "false" or word == "end"
            or (word == "loop" and stage >= 2)
            or ((word == "not" or word == "bool") and stage >= 3)
            or (word == "fragment" and stage == 4)
        check(puzzle.available(stage, word) == expected, "unlocks " .. stage .. ": " .. word)
    end
end
check(not puzzle.available(0, "true"), "invalid stage")
check(not puzzle.available(1, "unknown"), "unknown tile unavailable")

lights({}, "")
lights({ "true" }, "G")
lights({ "false" }, "B")
lights({ "true", "false", "loop" }, "GBGB")
lights({ "true", "false", "loop", "not" }, "BGBG")
lights({ "true", "true", "false", "bool" }, "GBG")
lights({ "false", "false", "true", "bool" }, "BGB")
lights({ "fragment", "not" }, "W")
lights({ "fragment", "true", "loop" }, "WGWG")
lights({ "fragment", "false", "bool" }, "GB")
lights({ "true", "false", "end" }, "G")
lights({ "end", "loop", "not", "bool", "end" }, "")
lights({ "true", "loop", "loop", "loop", "loop" }, string.rep("G", 16))
lights({ "true", "false", "false", "true", "true", "false" }, "GBBGGB")

local pulses, err = puzzle.evaluate({ "true", "loop", "loop", "loop", "loop", "true" })
check(pulses == nil and type(err) == "string" and err:find("16"), "append overflow visible")
pulses, err = puzzle.evaluate({ "true", "false", "true", "loop", "loop", "loop" })
check(pulses == nil and type(err) == "string" and err:find("16"), "loop overflow visible")
pulses, err = puzzle.evaluate({ "unknown" })
check(pulses == nil and type(err) == "string", "unknown tile error")
check(puzzle.matches({ "W", "W" }, "GB"), "wildcards match either color")
check(not puzzle.matches({ "W" }, "GB"), "exact length required")
check(not puzzle.matches({ "G" }, "B"), "different colors fail")
check(not puzzle.matches(nil, "G"), "nil output does not match")
check(not puzzle.matches({ "W" }, "X"), "wildcard only matches G/B")

local state = puzzle.new()
check(state.stage == 1 and #state.words == 0 and not state.won and state.attempts == 0,
    "new state")
check(not puzzle.add(state, "loop") and type(state.error) == "string", "locked tile rejected")
check(puzzle.add(state, "false"), "add available tile")
check(not puzzle.launch(state), "wrong launch fails")
check(state.stage == 1 and state.words[1] == "false" and state.attempts == 1,
    "failure preserves stage and strip")
puzzle.undo(state)
check(#state.words == 0 and state.error == nil, "undo frees tile and clears feedback")
puzzle.undo(state)
check(#state.words == 0, "undo empty strip")
for i = 1, 3 do check(puzzle.add(state, "true"), "use green tile " .. i) end
check(not puzzle.add(state, "true") and #state.words == 3, "finite green stock")
check(puzzle.count(state.words, "true") == 3, "count used tiles")
puzzle.clear(state)
check(state.attempts == 1 and state.stage == 1 and #state.words == 0, "clear keeps progress")
check(puzzle.add(state, "true"), "clearing restores stock")
check(puzzle.launch(state), "solve stage one")
check(state.stage == 2 and #state.words == 0 and not state.won, "advance clears strip")

local solutions = {
    { "true", "loop", "loop" },
    { "true", "false", "loop", "not" },
    { "true", "false", "false", "true", "true", "false" },
}
for _, solution in ipairs(solutions) do
    for _, word in ipairs(solution) do check(puzzle.add(state, word), "solution tile: " .. word) end
    check(puzzle.launch(state), "solution launch")
end
check(state.stage == 4 and state.won and state.attempts == 5, "all four stages won")
check(#state.words == 6, "winning strip remains visible")
check(not puzzle.add(state, "end"), "completed state rejects new tiles")
check(puzzle.launch(state) and state.attempts == 5, "won launch is idempotent")
puzzle.reset(state)
check(state.stage == 1 and #state.words == 0 and not state.won and state.attempts == 0
    and state.error == nil and state.pulses == nil, "reset restores initial state")

state.stage = 4
local wildcard_solution = { "true", "false", "fragment", "true", "true", "false" }
for _, word in ipairs(wildcard_solution) do check(puzzle.add(state, word), "wildcard solution tile") end
check(puzzle.launch(state) and state.won, "wildcard solves stage four")
puzzle.reset(state)
state.stage = 4
check(puzzle.add(state, "fragment"), "single fragment available")
check(not puzzle.add(state, "fragment"), "fragment stock limited to one")

-- Use legal stock to reach 16 pulses, then overflow on the next append.
puzzle.clear(state)
local overflow_solution = { "true", "false", "loop", "loop", "loop", "true" }
for _, word in ipairs(overflow_solution) do check(puzzle.add(state, word), "legal overflow tile") end
check(not puzzle.launch(state) and state.error:find("16") ~= nil, "launch displays overflow")
check(#state.words == 6 and state.stage == 4 and state.attempts == 1, "overflow preserves retry")
local full_strip = {}
for i, word in ipairs(puzzle.inventory) do full_strip[i] = word end
check(not puzzle.can_add(4, full_strip, "true"), "16 tile strip limit")
check(#puzzle.inventory == 16 and puzzle.stock["true"] == 3, "stock stays original")

print("PASS: " .. passed .. " assertions")
