-- Pure Lua 5.1+; no Defold APIs. Pulses are arrays of "G", "B", "W".
local inventory = require("main.inventory")
local M = {}

M.targets = { "G", "GGGG", "BGBG", "GBBGGB" }
M.titles = { "Una luz en casa", "Cuatro luces verdes", "Un baile de colores", "El gran nido" }
M.unlocks = {
    { "true", "false", "end" },
    { "true", "false", "end", "loop" },
    { "true", "false", "end", "loop", "not", "bool" },
    { "true", "false", "end", "loop", "not", "bool", "fragment" },
}
M.limit = 16
M.inventory = {}
M.stock = {}
for i, word in ipairs(inventory) do
    M.inventory[i] = word
    M.stock[word] = (M.stock[word] or 0) + 1
end

function M.available(stage, word)
    for _, unlocked in ipairs(M.unlocks[stage] or {}) do
        if unlocked == word then return true end
    end
    return false
end

function M.count(words, word)
    local total = 0
    for _, value in ipairs(words) do
        if value == word then total = total + 1 end
    end
    return total
end

function M.can_add(stage, words, word)
    if not M.available(stage, word) then
        return false, "Esta ficha todavía no está disponible."
    end
    if #words >= M.limit then
        return false, "La tira admite como máximo 16 fichas."
    end
    if M.count(words, word) >= (M.stock[word] or 0) then
        return false, "Ya usaste todas las fichas de este tipo."
    end
    return true
end

function M.evaluate(words)
    local pulses = {}
    for _, word in ipairs(words) do
        if not M.stock[word] then
            return nil, "Ficha desconocida: " .. tostring(word)
        end
        if word == "true" or word == "false" or word == "fragment" then
            if #pulses >= M.limit then
                return nil, "La fila supera el límite de 16 luces."
            end
            pulses[#pulses + 1] = word == "true" and "G" or word == "false" and "B" or "W"
        elseif word == "loop" then
            local length = #pulses
            if length * 2 > M.limit then
                return nil, "La fila supera el límite de 16 luces."
            end
            for i = 1, length do pulses[length + i] = pulses[i] end
        elseif word == "not" then
            for i, color in ipairs(pulses) do
                if color == "G" then pulses[i] = "B"
                elseif color == "B" then pulses[i] = "G" end
            end
        elseif word == "bool" then
            -- A leading wildcard resolves to green to make alternation deterministic.
            local first = pulses[1] == "B" and "B" or "G"
            local second = first == "G" and "B" or "G"
            for i = 1, #pulses do
                pulses[i] = i % 2 == 1 and first or second
            end
        elseif word == "end" then
            pulses[#pulses] = nil
        end
    end
    return pulses, nil
end

function M.matches(pulses, target)
    if not pulses or type(target) ~= "string" or #pulses ~= #target then return false end
    for i, color in ipairs(pulses) do
        local expected = target:sub(i, i)
        if expected ~= "G" and expected ~= "B" then return false end
        if color ~= "W" and color ~= expected then return false end
    end
    return true
end

function M.new()
    return { stage = 1, words = {}, won = false, attempts = 0 }
end

function M.add(state, word)
    if state.won then
        state.error = "¡Ya completaste todos los nidos!"
        return false, state.error
    end
    local allowed, err = M.can_add(state.stage, state.words, word)
    if not allowed then
        state.error = err
        return false, err
    end
    state.words[#state.words + 1] = word
    state.error = nil
    state.pulses = nil
    return true
end

function M.undo(state)
    state.words[#state.words] = nil
    state.error = nil
    state.pulses = nil
end

function M.clear(state)
    state.words = {}
    state.error = nil
    state.pulses = nil
end

function M.launch(state)
    if state.won then return true end
    state.attempts = state.attempts + 1
    local pulses, err = M.evaluate(state.words)
    state.pulses = pulses
    if err then
        state.error = err
        return false, err
    end
    if not M.matches(pulses, M.targets[state.stage]) then
        state.error = "Las luces aún no coinciden. Prueba otra combinación."
        return false, state.error
    end
    state.error = nil
    if state.stage == #M.targets then
        state.won = true
    else
        state.stage = state.stage + 1
        M.clear(state)
    end
    return true
end

function M.reset(state)
    M.clear(state)
    state.stage = 1
    state.won = false
    state.attempts = 0
end

return M
