-- Optional engine integration test. Normal play never loads this module.
local M={}
local plan={
 {capture="start"}, {click="loop",stage=1}, {click="false"}, {click="launch",stage=1},
 {capture="failure"}, {click="undo"}, {click="true"}, {click="false"}, {click="end"},
 {click="launch",stage=2}, {capture="loop_unlocked"},
 {click="true"},{click="loop"},{click="loop"},{click="launch",stage=3},
 {capture="transforms_unlocked"}, {click="false"},{click="loop"},{click="loop"},{click="bool"},
 {click="launch",stage=4},{capture="wildcard_unlocked"},
 {click="true"},{click="false"},{click="loop"},{click="not"},{click="clear"},
 {click="true"},{click="false"},{click="false"},{click="true"},{click="true"},{click="fragment"},
 {click="launch",won=true},{capture="victory"}, {click="reset",stage=1}, {capture="reset"},
 {click="true"},{click="true"},{click="true"},{click="true"},
 {verify=function(self) assert(#self.state.words==3,"stock exhausted") end},
 {click="clear"},{click="launch",stage=1}, {click="reset",stage=1},
 {verify=function(self) assert(#self.state.words==0 and self.state.attempts==0 and not self.state.won,"reset full state") end}
}
function M.new() return {time=0,index=0,recording=false} end
function M.update(self,dt,handler)
 local s=self.smoke s.time=s.time+dt
 if s.time<.65 then return end
 s.time=0
 if s.recording then msg.post("@system:","stop_record") s.recording=false return end
 s.index=s.index+1
 local step=plan[s.index]
 if not step then print("SMOKE PASS: GUI hit-test route, four nests, failed retry, stock and reset") sys.exit(0) self.smoke=nil return end
 if step.capture then
  local path=sys.get_config_string("project.capture_path","")
  msg.post("@system:","start_record",{file_name=path..step.capture..".ivf",frame_period=2,fps=30})
  s.recording=true
 elseif step.click then
  local button
  for _,b in ipairs(self.buttons) do if b.id==step.click then button=b break end end
  assert(button,"button exists: "..step.click)
  local p=gui.get_position(button.node)
  assert(handler(self,hash("touch"),{x=p.x,y=p.y,pressed=true}),"GUI button hit "..step.click)
  if step.stage then assert(self.state.stage==step.stage,"stage after "..step.click) end
  if step.won then assert(self.state.won,"victory visible") end
  print("SMOKE click="..step.click.." stage="..self.state.stage)
 elseif step.verify then step.verify(self) end
end
return M
