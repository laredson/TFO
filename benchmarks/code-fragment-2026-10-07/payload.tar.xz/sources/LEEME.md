Abre el game.project de cada carpeta con Defold 1.13.1. Las herramientas de pruebas locales y sus binarios auxiliares se han excluido; los tests Lua puros se conservan.
