# Jardín de luces

Un minijuego independiente de consola para Code Fragment. Haz florecer las cinco ramas copiando sus pedidos de soles amarillos y lunas azules. No hace falta saber programar.

## Abrir y jugar

Abre game.project con Defold 1.13.1 y ejecuta el proyecto. El paquete Windows está en dist: conserva toda la carpeta del ejecutable y sus recursos.

Usa el ratón. Mira el pedido, pulsa fichas y observa tu fila. Cuando sea igual, pulsa PLANTAR. Cada rama abre nuevas herramientas. Deshacer devuelve la última ficha; Limpiar devuelve todas las del pedido. Reiniciar comienza una partida nueva. No hay penalización por experimentar.

Inventario inicial: loop ×3, bool ×2, not ×2, true ×3, false ×3, end ×2, fragment ×1: 16 fichas. Se repone en cada pedido y al reiniciar. Una acción inválida no gasta fichas. Máximo ocho luces.

| Ficha | Efecto |
| --- | --- |
| true | Añade un sol. |
| false | Añade una luna. |
| loop | Copia la fila completa al final. |
| bool | Añade detrás de cada luz su opuesta. |
| not | Cambia todos los soles por lunas y viceversa. |
| end | Quita la última luz. |
| fragment | Añade la fila en orden inverso, como un espejo. |

## Recorrido reproducible

Desde una partida nueva, pulsa estas fichas y después PLANTAR en cada fila. Tras la celebración, pulsa SIGUIENTE PEDIDO. Al ganar, pulsa VER MI JARDÍN para ver el árbol y poder reiniciar.

1. true, true, true
2. true, bool, loop
3. false, false, true, true, loop
4. true, true, false, fragment
5. true, false, false, true, loop

El árbol completo debe mostrar la victoria. Pulsa Reiniciar: vuelve el primer pedido, cero ramas, fila vacía y las 16 fichas originales.

Error recuperable: al comienzo pulsa false y PLANTAR; el pedido no avanza. Pulsa Deshacer y continúa con el recorrido.

## Desarrollo y verificación

El registro definitivo de compilación, pruebas y revisión TFO está en ../evidence/result.json. Las instantáneas distinguen compilación, pruebas de reglas y partida interactiva.

Compilar desde PowerShell situado en main:

```powershell
& '..\tools\build.ps1' -ProjectPath (Get-Location).Path -Bundle
```

## Alcance

Cinco pedidos en un escenario. Los 2–3 minutos son una intención de diseño para explorar, no un tiempo impuesto. No se ha evaluado la comprensión con niños. Sin audio, guardado persistente ni conexión con el juego principal.


## Estado de entrega comprobado

- Compilación y bundle Windows: salida 0.
- Reglas Lua: 15.819 comprobaciones y 3.577 transformaciones exhaustivas aprobadas.
- Recorrido de callbacks de GUI con adaptador simulado: 30 comprobaciones aprobadas, cinco pedidos, ayuda, error recuperable, victoria y ambos botones de reinicio.
- Motor real: proceso y ventana identificados; sin errores Lua en el registro de arranque autorizado.
- Prueba visual/interactiva real: NO completada. Computer Use agotó captura/activación por timeout. La prueba simulada no certifica render ni entrada real.
- Revisión independiente HQ: NO completada. TFO quedó needs_review por recibos de mensajes con entidades XML; no se modificó TFO ni se duplicaron envíos.

No se considera una entrega totalmente validada hasta completar esas dos comprobaciones. Véase ../evidence/host-limitations.txt.


Copia pública: las rutas de herramientas y evidencias locales se han omitido. El proyecto editable se abre con game.project en Defold 1.13.1.
