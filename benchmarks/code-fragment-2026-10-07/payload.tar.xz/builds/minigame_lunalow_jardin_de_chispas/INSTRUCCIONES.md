# Jardín de chispas

Un rompecabezas de luces para la consola de Code Fragment. Guía al robot activando los tres focos de cada reto. No hay que escribir código; basta con tocar fichas y observar qué cambia.

## Abrir y jugar

- **Para jugar ahora:** abre `dist/Code Fragment Console/CodeFragmentConsole.exe`.
- **Para abrir el proyecto:** en Defold 1.13.1 elige **File → Open Project** y selecciona esta carpeta (`main`); abre `game.project` y pulsa **Ctrl+B**.
- **Ratón:** toca una ficha para añadirla a la fila; toca `end` o **PROBAR** para ejecutarla. **DESHACER** quita la última ficha; **BORRAR** limpia la fila; **REINICIAR** vuelve al inicio del reto actual.
- **Teclado:** `R` reinicia el reto (al terminar, vuelve al reto 1); `←` quita la última ficha.

Las fichas se reutilizan. Las 16 fichas visibles conservan las cantidades iniciales: `loop` ×3, `bool` ×2, `not` ×2, `true` ×3, `false` ×3, `end` ×2 y `fragment` ×1. Puedes probar una idea, mirar las luces, corregirla y volver a probar.

## Qué hace cada ficha

- `true`: enciende el foco seleccionado.
- `false`: apaga el foco seleccionado.
- `fragment`: mueve el foco seleccionado al siguiente.
- `bool`: hace que la siguiente ficha `true` o `false` actúe sobre los tres focos.
- `loop`: repite la siguiente ficha `true` o `false` por los tres focos, empezando por el seleccionado.
- `not`: invierte el efecto de la siguiente ficha `true` o `false`. Dos `not` seguidos se cancelan.
- `end`: ejecuta la fila que armaste. La ficha no se gasta.

Cada consola muestra su meta en amarillo y el jardín actual en verde/gris. Si no coincide, las luces conservan el resultado para que veas lo ocurrido; puedes añadir fichas, borrar, deshacer o reiniciar el reto. No hay castigo por equivocarse.

## Recorrido reproducible: ganar y reiniciar

1. **Reto 1 — La primera chispa:** toca `true` y después `end`. El foco 1 se enciende y aparece **SIGUIENTE**.
2. **Reto 2 — ¡Tres luces!:** toca `loop`, `true` y `end`. `true` enciende las tres luces mediante el `loop`.
3. **Reto 3 — Sombra, luz, sombra:** toca `bool`, `false`, `fragment`, `not`, `false` y `end`. `bool + false` apaga las tres; `fragment` selecciona el foco del centro; `not + false` lo enciende.
4. La consola muestra **MISIÓN CUMPLIDA**. Toca **REINICIAR** o pulsa `R` para comenzar desde el reto 1. En cualquier reto, **REINICIAR** o `R` permiten repetirlo sin perder la partida.

Una partida tranquila dura aproximadamente 2–3 minutos; quien ya conoce las fichas puede acabarla más rápido.

## Comprobaciones y límites

- Defold 1.13.1 compiló y empaquetó la versión Windows con `tools/build.ps1 -ProjectPath main -Bundle`. Se guardaron todos los logs de intentos en `evidence/`; el intento 10, tras el ajuste final, registró salida 0. En la continuación, Computer Use localizó el proceso y Windows lo reportó `Responding` en dos consultas separadas por cinco segundos. Esto verifica presencia/respuesta del proceso, no que se renderice bien ni que el juego acepte clics. Computer Use falló dos capturas de la ventana con timeout, incluida una tras refrescar la selección; por eso no se hizo una partida manual.
- La compilación confirma que Defold acepta los recursos y scripts. **No confirma por sí sola que se haya completado una partida**. La ruta anterior es reproducible a partir de las reglas implementadas, pero esta entrega no cuenta con una prueba manual completa ni con una prueba con niños.
- La presentación usa formas y texto creados por el código y la fuente incluida en Defold. Aún no se ha hecho una revisión visual con público infantil.
- El arte es deliberadamente sencillo y el prototipo es independiente: no guarda progreso ni se conecta al juego principal.






Copia pública: las rutas de herramientas y evidencias locales se han omitido. El proyecto editable se abre con game.project en Defold 1.13.1.
