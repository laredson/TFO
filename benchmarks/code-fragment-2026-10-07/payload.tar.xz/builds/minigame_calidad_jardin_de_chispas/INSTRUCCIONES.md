# Jardín de chispas

Minijuego independiente para las consolas de Code Fragment: despierta cinco flores formando trenes de luz con fichas. Cada flor abre nuevas combinaciones. No se escribe código, no hay vidas ni límite de tiempo.

## Abrir y jugar

- **Windows:** abre `dist/Jardin de chispas/Jardindechispas.exe`. Conserva los otros cuatro archivos del bundle junto al ejecutable.
- **Defold 1.13.1:** abre `game.project` y ejecuta el proyecto. Sin extensiones ni descargas.
- Clic en una ficha para añadirla al tren de cuatro espacios. **TU SALIDA** anticipa sus símbolos.
- **Probar** compara las chispas, una a una, con el pedido. Coinciden **cantidad, símbolos y orden**: la flor despierta. Pulsa **Siguiente flor** para avanzar.
- **Atrás** quita la última ficha; **Borrar** vacía el tren. Corregir un intento no cuesta nada.
- **R** reinicia todo, incluso durante una animación. Tras ganar, **Otra vez** hace lo mismo. Cierra la ventana para salir.

Sol y luna tienen formas distintas; pausa son dos barras y arcoíris es un rombo brillante. Los ejemplos de las fichas activas se dibujan con símbolos. Las palabras originales son nombres de piezas: no necesitas conocer programación.

## Las 16 fichas

`INICIO` muestra las copias totales y `LIBRES` las no colocadas. Las fichas dormidas muestran en qué flor despiertan. Todas se reutilizan al quitarlas o cambiar de flor.

| Ficha | Inicial | Efecto |
|---|---:|---|
| true | 3 | Añade sol. |
| false | 3 | Añade luna. |
| loop | 3 | Repite el último símbolo. Flor 2. |
| not | 2 | Añade el color contrario al último. Flor 3. |
| bool | 2 | Añade contrario y luego mismo: sol → sol, luna, sol. Flor 4. |
| end | 2 | Añade pausa. Flor 4. |
| fragment | 1 | Añade arcoíris, válido como sol, luna o arcoíris, nunca pausa. Flor 5. |

`loop` necesita un símbolo anterior; también repite pausa o arcoíris. `not` y `bool` necesitan sol o luna inmediatamente anteriores. Una receta inválida muestra un aviso y permite corregir. Las cantidades iniciales se conservan siempre.

## Recorrido reproducible

Empieza con **R**. Añade cada fila en orden, pulsa **Probar**, espera y pulsa **Siguiente flor**.

| Flor | Fichas | Resultado |
|---|---|---|
| 1 | true, false | sol, luna |
| 2 | true, loop, loop, loop | cuatro soles |
| 3 | false, loop, not, loop | luna, luna, sol, sol |
| 4 | true, bool, end | sol, luna, sol, pausa |
| 5 | false, bool, end, fragment | luna, sol, luna, pausa, arcoíris |

La quinta muestra **Victoria**, cinco flores despiertas y **Otra vez**. Púlsalo: flor 1, tren vacío, 16 copias libres y bloqueos iniciales. Para comprobar el error recuperable, envía sólo `true` en la primera flor, espera el aviso, añade `false` y vuelve a probar.

## Compilar y comprobar

Desde la carpeta de la variante:

```powershell
.\tools\build.ps1 -ProjectPath .\main -Bundle
.\tools\test-game.ps1 -LogName prueba-local
```

La segunda orden activa `--config=garden.autotest=1` en una instancia oculta del mismo ejecutable. El modo de prueba está desactivado al abrir normalmente. Emite eventos sintéticos al manejador real de entrada usando los nodos GUI y espera las animaciones; no equivale a clics físicos ni a revisión visual.

Pruebas de reglas desde `main`, con LuaJIT incluido en Defold y extraído sin descargas:

```powershell
..\worker-1\test-tools\luajit-64.exe .\tests\garden_test.lua
```

## Resultados y límites

- Compilación y bundle Windows comprobados con Defold 1.13.1.
- Reglas: 8 grupos, 59.883 aserciones y 14.005 recetas correctas. También ejecutadas dentro del motor en el arnés aislado.
- Recorrido automático integrado: cinco flores, error recuperable, devolución de fichas, bloqueo durante animación, victoria persistente, botón de reinicio y R durante animación comprobados.
- **Revisión visual y recorrido con ratón físico pendientes:** el capturador agotó el tiempo de espera y quedó con una petición activa incluso tras restablecerlo. No se inventan capturas ni evaluación visual.
- El sandbox impidió inicialmente arrancar Defold (`dmCrash::IsInitialized()`). El mismo ejecutable funcionó fuera del entorno restringido. No se cambiaron opciones globales.
- Duración prevista: 2–3 minutos de descubrimiento, no medida con niños; con la solución se termina más rápido. Comprensión infantil, atractivo y sonido audible no evaluados con una persona.
- Un escenario, cinco pedidos fijos, sin guardado ni conexión con el juego principal. Sonido sintetizado original; gráficos de formas y fuente incluida en Defold.
- Bob advierte sobre limpieza de algunos temporales; compilaciones finales con código 0. Intentos fallidos y correcciones conservados.

## Organización y evidencia

TFO **Calidad**: maestro Astra medio; reglas Sol 6.1 medio (Normal Luna medio); interfaz Astra medio (Normal Sol 6.1 medio). Selecciones reales verificadas por recibos nativos. Calidad no exige revisor independiente adicional. El maestro integró, revisó y validó.

Flujo `flow_muy3kk9f_3f9a6990c5`. En `../evidence`: recibos, medidas disponibles, hitos UTC, instantáneas y resultado estructurado. No se atribuye cuota semanal individual ni se inventan puntuaciones.

## Interrupción y recuperación del cierre

El 7 de octubre se interrumpió el cierre por un fallo externo de revisión automática: `failed to load workspace requirements`. La llamada de checkpoint no se ejecutó. El controlador comunicó que reparó una escritura CRLF ajena al juego y autorizó continuar. Se recuperó el propietario real del flujo con TFO y se reanudó sin reenviar ninguna tarea a auxiliares. El ejecutable conserva exactamente el SHA-256 de la entrega ya probada.

El intervalo aproximado entre el registro final previo (13:08:37 UTC) y la recuperación (13:22:53 UTC) se registra como interrupción, no como desarrollo activo. El inicio exacto del bloqueo no está medido; no se inventa tiempo activo neto. La limitación de captura visual sigue documentada por separado.


Copia pública: las rutas de herramientas y evidencias locales se han omitido. El proyecto editable se abre con game.project en Defold 1.13.1.
