# Taller de luciérnagas

Prototipo independiente Defold 1.13.1, Windows, una escena y una mecánica: combinar fichas reutilizables para dibujar una fila de luces y enviarla a tres flores.

## Abrir
Ejecuta dist/Taller de luciernagas/Tallerdeluciernagas.exe manteniendo juntos todos los archivos del paquete. Para editar, abre game.project en Defold. Ventana 960 × 640. Cierra con la X de Windows.

## Jugar
Clic izquierdo en una ficha: entra en la fila. Clic en una ficha de la fila: vuelve al inventario. VISTA muestra inmediatamente el resultado. ENVIAR compara colores, orden y cantidad con la flor activa. BORRAR devuelve todas las fichas. VOLVER A EMPEZAR restablece flores, fila y desbloqueos.

Las 16 fichas físicas siempre aparecen: loop ×3, bool ×2, not ×2, true ×3, false ×3, end ×2, fragment ×1. Cada ficha física puede estar seleccionada una sola vez. Hay ocho espacios de fila. No se gastan: al regar una flor vuelven todas. Los errores no quitan progreso ni fichas.

## Reglas de izquierda a derecha
- true añade una luz amarilla.
- false añade una luz azul.
- not cambia la última luz amarilla por azul o azul por amarilla. El arcoíris no cambia. Necesita una luz previa.
- bool activa/desactiva alternar. No añade luz; necesita una luz previa.
- loop añade otra luz del último color. Si alternar está activo, cambia amarillo/azul antes de añadirla. El arcoíris se repite igual.
- fragment añade una luz arcoíris, representada por un círculo rosa con estrella.
- end detiene la lectura: las fichas que siguen no producen luces.

## Progresión
Flor 1 pide amarillo y permite true/false. Al completarla despiertan not, bool y loop.
Flor 2 pide azul, amarillo, azul. Al completarla despiertan fragment y end.
Flor 3 pide dos arcoíris. Al completarla aparece victoria y PROBAR permite experimentar libremente con todas las fichas.
Toda la partida usa la misma fila y vista inmediata.

## Recorrido exacto
1. true → ENVIAR.
2. false → bool → loop → una segunda ficha loop → ENVIAR.
3. fragment → loop → end → ENVIAR.
4. Comprueba el mensaje de victoria y prueba fragment → PROBAR.
5. VOLVER A EMPEZAR: vuelve flor 1, fila vacía y fichas avanzadas dormidas.
Alternativa de descubrimiento: en flor 2, true → not → bool → loop → loop también produce azul, amarillo, azul.

## Compilación y pruebas
Desde PowerShell:
& '..\tools\build.ps1' -ProjectPath $PWD -Bundle

Pruebas reales dentro del paquete (desde su directorio):
.\Tallerdeluciernagas.exe --config=tests.enabled=1
.\Tallerdeluciernagas.exe --config=tests.enabled=2

1 ejecuta asserts de reglas. 2 simula clics sobre nodos GUI reales, separados por fotogramas, y comprueba los tres avances, victoria, probar, borrar y reinicio. Ambos imprimen PASSED y salen con código 0. evidence/build.log, engine-1.log y engine-2.log conservan resultados. En este entorno el ejecutable requirió salir del aislamiento de archivos para inicializar el registro de errores de Windows; dentro del aislamiento se produjo una aserción del motor antes del arranque.

Pruebas sin motor usando el LuaJ que ya incluye Defold:
java -cp '<Defold>\packages\defold-574678c7d44be490d874fbed2d0ae6211feec4d9.jar' lua tests/run.lua
java -cp '<Defold>\packages\defold-574678c7d44be490d874fbed2d0ae6211feec4d9.jar' lua tests/gui_test.lua
La segunda usa un adaptador, y no sustituye la prueba GUI real.

## Límites
Diseñado para explorar durante 2–3 minutos, sin cronómetro ni castigos. No se ha medido con un niño ni validado comprensión infantil. No hay audio, guardado ni integración con Code Fragment. El arcoíris usa un símbolo simplificado. Se comprobó creación y funcionamiento de GUI en el motor; no se realizó inspección manual de una captura ni prueba humana de legibilidad.

## Validación de la versión integrada en main
Compilación final: evidence/build-final.log, código 0. Reglas y recorrido de GUI real: evidence/final-test-1.log y final-test-2.log, ambos código 0. Los registros del maestro están en la carpeta evidence de la raíz saving (un nivel por encima de main).

Las luces incluyen símbolos: + amarillo, o azul, * arcoíris. Al enviar vuelan hacia la flor. Las pistas avanzadas invitan a experimentar; el recorrido exacto está arriba.

Comandos reproducibles, desde el directorio del ejecutable:
```powershell
.\Tallerdeluciernagas.exe --config=graphics.adapter=opengl --config=tests.enabled=1
.\Tallerdeluciernagas.exe --config=graphics.adapter=opengl --config=tests.enabled=2
```
En Windows normal puede ejecutarse directamente el .exe. Si hace falta, el parámetro OpenGL reproduce la configuración comprobada.

No se certifica inspección visual: Computer Use no pudo capturar la ventana (FrameArrived timeout). Se comprobaron mediante motor real nodos, detección de puntos, progreso, victoria y reinicio. La prueba automática inyecta las acciones del juego; no certifica el hardware del ratón ni comprensión infantil. Una solución conocida tarda menos que la meta exploratoria de 2–3 minutos; esa duración aún no está medida con un jugador nuevo.

Referencias técnicas oficiales consultadas: https://defold.com/manuals/project-settings/ y https://defold.com/ref/gui/ . El runtime comprobado es el instalado 1.13.1.

Actualización Computer Use: autorización expresa recibida; se reinició el entorno y se localizó nuestra ventana (237 ms). Captura inicial y único reintento fallaron con FrameArrived/window capture timeout. No hubo solicitud de permiso observable ni clics enviados. Ver evidence/computer-use-followup.json en la raíz saving. La inspección visual sigue sin verificar.


Copia pública: las rutas de herramientas y evidencias locales se han omitido. El proyecto editable se abre con game.project en Defold 1.13.1.
