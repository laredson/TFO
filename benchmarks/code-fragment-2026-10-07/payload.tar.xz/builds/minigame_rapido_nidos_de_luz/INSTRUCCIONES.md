# Nidos de luz

Prototipo independiente de consola para Code Fragment. Una escena, cuatro nidos y una sola mecánica: combinar fichas para construir luces. Diseñado para unos 2–3 minutos de descubrimiento, sin reloj ni vidas. La duración infantil todavía no se ha medido.

## Abrir y jugar

En Windows abre `dist/Nidos de luz/Nidosdeluz.exe`. Mantén junto al ejecutable los cuatro archivos `game.*` de esa misma carpeta. No requiere instalar Defold. Para editar, abre `game.project` con Defold 1.13.1 y ejecuta Build.

Solo ratón: clic en una ficha para añadirla a la tira. La vista «Tus luces» cambia inmediatamente. Crea la misma fila que «El nido pide» y pulsa **DESPERTAR**. Los círculos verdes llevan +; los cuadrados azules llevan −. El orden y el número de luces cuentan. El nido despierto cambia a dorado y el siguiente reto aparece automáticamente.

**Deshacer** devuelve la última ficha colocada; **Limpiar** devuelve todas sin perder el nido; **Pista** muestra un ejemplo. **Reiniciar** o **VOLVER A JUGAR** restablecen la partida completa. Pasar el ratón sobre una ficha muestra su efecto. Fallar conserva tu tira y marca luces distintas; puedes corregir sin penalización.

## Las 16 fichas

Cada tarjeta agrupa copias físicas: disponible / cantidad inicial. Las bloqueadas permanecen visibles. Las copias se devuelven al deshacer, limpiar o pasar de nido.

| Palabra visible | Copias iniciales | Efecto al colocarla |
|---|---:|---|
| true | 3 | Añade una luz verde circular +. |
| false | 3 | Añade una luz azul cuadrada −. |
| end | 2 | Quita la última **luz**, sin devolver otras fichas. |
| loop | 3 | Duplica toda la fila de luces que ya tienes. |
| not | 2 | Intercambia todos los verdes y azules. Conserva comodines. |
| bool | 2 | Alterna la fila desde su primer color, sin cambiar su longitud. |
| fragment | 1 | Añade una luz dorada con dos colores: coincide con cualquier color en una posición. |

Al empezar están disponibles true, false y end. El segundo nido abre loop; el tercero abre not y bool; el cuarto abre fragment. Las transformaciones en una fila vacía no crean luces. Si bool empieza con un comodín, empieza verde y convierte toda la fila a verdes/azules alternados. La fila admite 16 luces: un exceso muestra error; Deshacer o Limpiar lo corrigen. No se recorta silenciosamente ni se consumen fichas.

## Recorrido reproducible

Pulsa Reiniciar. Antes de cada fila puedes pulsar Limpiar. Coloca en el orden indicado y pulsa DESPERTAR una vez:

1. `true, false, end` → verde. Despierta el primer nido y abre loop.
2. `true, loop, loop` → cuatro verdes. Abre not y bool.
3. `false, loop, loop, bool` → azul, verde, azul, verde. Abre fragment. Alternativa: `true, false, loop, not`.
4. `true, false, false, true, true, fragment` → verde, azul, azul, verde, verde, comodín. Aparece «¡Todos despiertos!».
5. Pulsa VOLVER A JUGAR. Debes volver al nido 1, tira vacía, cantidades 3/3, 3/3, 2/2, 3/3, 2/2, 2/2, 1/1 y los cuatro tipos posteriores bloqueados.

Para comprobar un fallo, en nido 1 coloca false y pulsa DESPERTAR: permanece el nido 1 y aparece X bajo la luz azul. Deshacer devuelve esa ficha; true permite acertar. Tres true agotan sus copias; un cuarto clic no añade otra. Limpiar restituye las tres.

## Comprobaciones y evidencias

Las pruebas puras se incluyen en `main/tests.lua`; se ejecutan dentro del motor pasando `--config=project.test=1` al ejecutable. El recorrido de integración opcional se activa con `--config=project.smoke=1` y `--config=project.capture_path=<carpeta con / final>`. Envía entradas a la misma función y prueba los botones con `gui.pick_node`; no simula un ratón físico del sistema. Graba imágenes del propio motor en IVF. Juego normal no activa estas herramientas.

Los resultados finales, errores iniciales conservados, grabaciones, capturas, recibos TFO e instantáneas de fuentes están en `../evidence`. Dos auxiliares produjeron lógica/pruebas y recorrido/copy. Algunas sugerencias de QA eran alternativas de diseño: aquí se adoptó Deshacer de última ficha, avance automático y límite explícito de 16 luces.

Comprobación final: compilación Windows con salida 0; 116 aserciones de reglas con salida 0; recorrido de botones de la interfaz con salida 0 y registro de errores vacío. El recorrido despertó los cuatro nidos, ejercitó todas las fichas, comprobó fallo/reintento, agotamiento de copias y reinicio. Se inspeccionaron imágenes reales del motor; también se verificó la fuente española ampliada y el contraste de los botones.

## Límites conocidos

Sin conexión aún con el juego principal, persistencia, sonido ni evaluación con niños. La duración de 2–3 minutos es una intención de diseño. El control de ventanas de Windows no consiguió capturar el juego; la comprobación visual usa imágenes grabadas por Defold. Los clics del sistema y la comodidad real de un niño quedan pendientes. El motor requiere acceso normal a su carpeta de registro de errores de Windows; bajo el aislamiento de herramientas falló su inicialización, fuera de ese aislamiento arrancó.

TFO recibió ambos chats y sus modelos reales se verificaron. La entrega de lógica contiene `&gt;` donde el prompt guardado tenía `>`; el observador no acepta su recibo automáticamente. Se conserva el turno completado y la selección observada, sin reenviar ni modificar TFO. Consultar `../evidence/tfo-status-final.json` para el estado de cierre real.

Documentación técnica consultada: [GUI de Defold](https://defold.com/manuals/gui/) y [API del sistema y grabación](https://defold.com/ref/sys-lua/).


Copia pública: las rutas de herramientas y evidencias locales se han omitido. El proyecto editable se abre con game.project en Defold 1.13.1.
