# Builds Code Fragment

Extrae todo el ZIP. Cada minijuego está en su carpeta con sus archivos vecinos y su guía INSTRUCCIONES.md. Ejecutables para Windows x64, Defold 1.13.1. Siete modos disponibles; tres pendientes. Luna low y HQ tienen validación incompleta. Consulta el informe del benchmark para condiciones y límites.
